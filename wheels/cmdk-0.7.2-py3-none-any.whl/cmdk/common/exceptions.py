

class SDKException(Exception):
    def __init__(self, msg, code, extra=None):
        self.code = code
        self.msg = msg
        self.extra = extra
        
    def __str__(self):
        msg = f"code={self.code}, msg='{self.msg}'"
        if self.extra:
            msg += f", extra={self.extra}"
        return msg


class MSSServerException(SDKException):
    pass


class ResourceNotFound(SDKException):
    def __init__(self, msg, extra=None):
        super().__init__(msg=msg, code=1000, extra=extra)
        

class UnsupportedError(SDKException):
    def __init__(self, msg, extra=None):
        super().__init__(msg=msg, code=1001, extra=extra)


class InvalidMCAPError(SDKException):
    def __init__(self, msg, extra=None):
        super().__init__(msg=msg, code=1002, extra=extra)


class InvalidFrameError(SDKException):
    def __init__(self, msg, extra=None):
        super().__init__(msg=msg, code=1003, extra=extra)


class InvalidMessageError(SDKException):
    def __init__(self, msg, extra=None):
        super().__init__(msg=msg, code=1004, extra=extra)


class InvalidProtoError(SDKException):
    def __init__(self, msg, extra=None):
        super().__init__(msg=msg, code=1005, extra=extra)


class ClosedError(SDKException):
    def __init__(self, msg, extra=None):
        super().__init__(msg=msg, code=1006, extra=extra)


class InvalidParamError(SDKException):
    def __init__(self, msg, extra=None):
        super().__init__(msg=msg, code=1007, extra=extra)


class DecodeError(SDKException):
    def __init__(self, msg, extra=None):
        super().__init__(msg=msg, code=1008, extra=extra)


class MCAPObstructedError(SDKException):
    def __init__(self, msg, extra=None):
        super().__init__(msg=msg, code=1009, extra=extra)