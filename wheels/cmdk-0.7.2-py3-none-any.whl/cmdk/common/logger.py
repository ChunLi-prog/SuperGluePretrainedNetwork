import logging
from logging.handlers import RotatingFileHandler
import os
from pathlib import Path
import sys
from typing import Union, TextIO

from rich.logging import RichHandler
from rich.console import Console

class CMDKLogger:
    def __init__(self):
        self._logger = logging.getLogger("cmdk")
        self._logger.setLevel(logging.CRITICAL)
        self.default_format = "%(asctime)s - %(name)s - %(levelname)s - %(filename)s:%(lineno)d - %(message)s"
        
        if not self._logger.handlers:
            self._logger.addHandler(logging.NullHandler())
    
    def get_logger(self) -> logging.Logger:
        return self._logger
    
    def enable_console_logging(
        self, 
        stream: TextIO = sys.stdout, 
        level: Union[int, str] = logging.INFO, 
        format: str = None
    ):
        console_handler = logging.StreamHandler(stream)
        console_handler.setLevel(level)
        
        formatter = logging.Formatter(format or self.default_format)
        console_handler.setFormatter(formatter)
        
        self._remove_handlers(logging.StreamHandler, RichHandler)
        self._logger.addHandler(console_handler)
        self.set_level(level)

    def enable_rich_console_logging(
        self, 
        stream: TextIO = sys.stdout, 
        level: Union[int, str] = logging.INFO, 
    ):
        console_handler = RichHandler(
            level=level, 
            console=Console(file=stream), 
            show_path=False, 
            log_time_format="%Y-%m-%d %H:%M:%S", 
            omit_repeated_times=False,
            rich_tracebacks=True,
        )
        
        self._remove_handlers(logging.StreamHandler, RichHandler)
        self._logger.addHandler(console_handler)
        self.set_level(level)
        os.environ["_CMDK_RICH_LOGGING"] = "1"
    
    def enable_file_logging(
        self, 
        file_path: str, 
        level: int = logging.INFO, 
        format: Union[int, str] = None, 
        max_bytes: int = 50 * 1024 * 1024, 
        backup_count: int = 10
    ):
        file_path = Path(file_path)
        file_path.parent.mkdir(parents=True, exist_ok=True)
        
        file_handler = RotatingFileHandler(
            file_path,
            maxBytes=max_bytes,
            backupCount=backup_count,
            encoding="utf-8"
        )
        file_handler.setLevel(level)
        
        formatter = logging.Formatter(format or self.default_format)
        file_handler.setFormatter(formatter)
        
        self._remove_handlers(logging.FileHandler)
        self._logger.addHandler(file_handler)
        if self._logger.level > level:
            self.set_level(level)

    def add_custom_handler(self, handler: logging.Handler):
        self._logger.addHandler(handler)

    def set_level(self, level: Union[int, str]):
        self._logger.setLevel(level)

    def disable_logging(self):
        self._logger.handlers.clear()
        self._logger.addHandler(logging.NullHandler())
        self._logger.setLevel(logging.CRITICAL)
    
    def _remove_handlers(self, *handler_types):
        rm_handlers = [hander for hander in self._logger.handlers if isinstance(hander, handler_types)]
        for handler in rm_handlers:
            self._logger.removeHandler(handler)
            handler.close()


_LOGGER = CMDKLogger()


def setup_logging(
    console: bool = False,
    rich_console: bool = False,
    file_path: str = None,
    level: Union[int, str] = logging.INFO,
    format: str = None
):
    if rich_console:
        _LOGGER.enable_rich_console_logging(level=level)
    elif console:
        _LOGGER.enable_console_logging(level=level, format=format)
    if file_path:
        _LOGGER.enable_file_logging(file_path=file_path, level=level, format=format)
    if not (console or rich_console or file_path):
        _LOGGER.disable_logging()


def get_logger() -> logging.Logger:
    return _LOGGER.get_logger()


def disable_logging():
    _LOGGER.disable_logging()
