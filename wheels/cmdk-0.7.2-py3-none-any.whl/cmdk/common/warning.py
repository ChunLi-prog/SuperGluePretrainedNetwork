"""wannings."""

class CMDKWarning(UserWarning):
    """Base warning class for CMDK library."""
    pass


class CMDKDeprecationWarning(CMDKWarning):
    """Warning class for deprecated features in CMDK library."""
    pass
