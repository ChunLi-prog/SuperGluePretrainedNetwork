import enum


class LidarDataType(enum.IntEnum):
    INT16_COMPRESSED = 1
    FLOAT32_RAW = 2
    FLOAT32_COMPRESSED = 3


class CompressionType(enum.Enum):
    NONE = ""
    ZSTD = "zstd"
    LZ4 = "lz4"


class SchemaEncoding(enum.Enum):
    PROTOBUF = "protobuf"
    JSON = "jsonschema"
    ROS2 = "ros2msg"


class ChannelEncoding(enum.Enum):
    PROTOBUF = "protobuf"
    JSON = "json"
    CDR = "cdr"
