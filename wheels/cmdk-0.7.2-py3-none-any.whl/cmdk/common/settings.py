import getpass
from pathlib import Path
import tempfile

CMDK_BASE_DIR = Path(__file__).absolute().parents[1]

USERNAME = getpass.getuser()

CMDK_HOME = Path.home() / ".cmdk"

CONFIG_DIR = CMDK_HOME / "config"
CACHE_DIR = CMDK_HOME / "cache"
INDEX_CACHE_DIR = CMDK_HOME / "cache" / "index"
FRAME_CACHE_DIR = CMDK_HOME / "cache" / "frame"

# INDEX_CACHE_DIR.mkdir(parents=True, exist_ok=True)

TMP_DIR = Path(tempfile.gettempdir()) / "cmdk"
# TMP_DIR.mkdir(parents=True, exist_ok=True)


MSS_SERVER_ENDPOINT = {
    "prod": "https://data.gaia.carizon.work/mss",
    "test": "https://data-test.gaia.carizon.work/mss",
}

OFFICE_DNS = {
    "data.gaia.carizon.work": "10.29.12.128",
    "data-test.gaia.carizon.work": "10.29.12.128",
}

CLOUD_DNS = {
    "data.gaia.carizon.work": "10.35.1.159",
    "data-test.gaia.carizon.work": "10.35.1.159",
}

DISABLE_MCAP_OBSTRUCT_ENV = "DISABLE_CMDK_MCAP_OBSTRUCT"
