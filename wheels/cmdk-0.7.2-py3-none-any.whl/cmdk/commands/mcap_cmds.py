import json
import os
import sys
import typer
from typing_extensions import Annotated

import cmdk
from cmdk.mcap.doctor import mcap_doctor
from cmdk.mcap.recover import mcap_recover
from cmdk.utils import mcap_obstructer

mcap_app = typer.Typer(help="MCAP Commands")


@mcap_app.command("obstruct", help="检测转换的MCAP文件或目录中是否有脏数据")
def obstruct(
    mcap_path: Annotated[str, typer.Argument(help="MCAP文件或MCAP目录.")],
):
    os.environ["ENABLE_NONE_CONVERT_MCAP_CHECK"] = "1"
    cmdk.setup_logging(console=True)
    sys.exit(mcap_obstructer.obstructer.check(mcap_path))


@mcap_app.command("doctor", 
                  short_help=f"检测MCAP文件是否有效.", 
                  help=f"检测CAP文件的是否符合Carizon规范, 退出码定义如下(多个错误类型时取最小值):\n\n{mcap_doctor.CheckStatusCode._to_help()}")
def doctor(
    mcap_path: Annotated[str, typer.Argument(help="MCAP文件.")],
    result_file: Annotated[str, typer.Option(help="结果状态码输出路径.")] = "",
):
    cmdk.setup_logging(rich_console=True)
    doctor = mcap_doctor.MCAPDoctor(mcap_path)
    results = doctor.run_check()
    if result_file:
        result_file = os.path.abspath(result_file)
        result_data = json.dumps({code.name: code.value for code in results if code.value > 0}, indent=4)
        with open(result_file, "w") as f:
            f.write(result_data)
        print(f"结果已写入文件: {result_file}\n{result_data}")
    error_codes = [code for code in results if code.value > 0]
    exit_code = min(error_codes) if error_codes else 0
    sys.exit(exit_code)


@mcap_app.command("recover", short_help="修复MCAP文件", help=f"修复有问题的MCAP, 暂支持修复写中断类型. 退出码定义如下:\n\n{mcap_recover.RecoveryStatus._to_help()}")
def doctor(
    input_mcap: Annotated[str, typer.Option("--input-mcap", "-i", help="输入待修复的MCAP文件.")],
    output_mcap: Annotated[str, typer.Option("--output-mcap", "-o", help="输出MCAP文件.")],
    recover_empty_file: Annotated[bool, typer.Option(help="是否修复空文件.")] = False,
):
    cmdk.setup_logging(rich_console=True)
    recover = mcap_recover.MCAPRecover(
        mcap_path=input_mcap,
        output_path=output_mcap,
        recover_empty_file=recover_empty_file
    )
    sys.exit(recover.run())
