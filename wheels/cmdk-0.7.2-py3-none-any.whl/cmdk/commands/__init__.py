import typer

import cmdk
from cmdk.commands import mcap_cmds


cmd = typer.Typer(
    name="cmdk", 
    help="CMDK CLI Tool, Document: https://carizon.feishu.cn/wiki/AwvBwuHlJiIBEjkVQguc62IXncg", 
    add_completion=True, 
    no_args_is_help=True,
    context_settings={"help_option_names": ["-h", "--help"]}
)


cmd.add_typer(mcap_cmds.mcap_app, name="mcap", no_args_is_help=True)


@cmd.command(name="version", help="Show CMDK version")
def show_version():
    print(f"CMDK {cmdk.__version__}")
