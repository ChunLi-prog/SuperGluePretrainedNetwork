from os import PathLike
from typing import List, Union, Callable, Optional

from cmdk.mcap import MCAPReader, MCAPWriter, DirectoryReader, Frame, Message


FrameOrMsg = Union[Frame, Message]

SliceFuncType = Callable[[FrameOrMsg], Optional[FrameOrMsg]]


class MCAPSlicer:
    def slice_file(
        self,
        input_path: Union[str, PathLike],
        output_path: Union[str, PathLike],
        start_timestamp_ms: int = None,
        end_timestamp_ms: int = None,
        topics: List[str] = None,
        slicer_func: SliceFuncType = None,
        writer_params: dict = None,
    ) -> int:
        """Slice MCAP file from input_path to output_path.

        Args:
            input_path (Union[str, PathLike]): input MCAP file path.
            output_path (Union[str, PathLike]): output MCAP file path.
            start_timestamp_ms (int, optional): start timestamp ms. Defaults to None.
            end_timestamp_ms (int, optional): end timestamp ms. Defaults to None.
            topics (List[str], optional): topics to slice. Defaults to None.
            slicer_func (SliceFuncType, optional): custom slicer function. Defaults to None.
            writer_params (dict, optional): MCAPWriter parameters. Defaults to None.
        Returns:
            int: total count of messages and frames sliced.
        """
        with MCAPReader(input_path) as reader, MCAPWriter(output_path, **(writer_params or {})) as writer:
            return self.slice_reader(
                reader,
                writer,
                start_timestamp_ms=start_timestamp_ms,
                end_timestamp_ms=end_timestamp_ms,
                topics=topics,
                slicer_func=slicer_func,
            )

    def slice_directory(
        self,
        input_directory: Union[str, PathLike],
        output_path: Union[str, PathLike],
        start_timestamp_ms: int = None,
        end_timestamp_ms: int = None,
        topics: List[str] = None,
        slicer_func: SliceFuncType = None,
        writer_params: dict = None,
    ) -> int:
        """Slice MCAP director from input_directory to output_path.

        Args:
            input_directory (Union[str, PathLike]): input MCAP directory.
            output_path (Union[str, PathLike]): output MCAP file path.
            start_timestamp_ms (int, optional): start timestamp ms. Defaults to None.
            end_timestamp_ms (int, optional): end timestamp ms. Defaults to None.
            topics (List[str], optional): topics to slice. Defaults to None.
            slicer_func (SliceFuncType, optional): custom slicer function. Defaults to None.
            writer_params (dict, optional): MCAPWriter parameters. Defaults to None.
        Returns:
            int: total count of messages and frames sliced.
        """
        with DirectoryReader(input_directory) as reader, MCAPWriter(output_path, **(writer_params or {})) as writer:
            return self.slice_reader(
                reader,
                writer,
                start_timestamp_ms=start_timestamp_ms,
                end_timestamp_ms=end_timestamp_ms,
                topics=topics,
                slicer_func=slicer_func,
            )
    
    def slice_reader(
        self,
        reader: Union[MCAPReader, DirectoryReader],
        writer: MCAPWriter,
        start_timestamp_ms: int = None,
        end_timestamp_ms: int = None,
        topics: List[str] = None,
        slicer_func: SliceFuncType = None,
    ) -> int:
        """Slice MCAPReader/DirectoryReader to MCAPWriter.
        
        Args:
            reader (Union[MCAPReader, DirectoryReader]): input reader.
            writer (MCAPWriter): output MCAPWriter.
            start_timestamp_ms (int, optional): start timestamp ms. Defaults to None.
            end_timestamp_ms (int, optional): end timestamp ms. Defaults to None.
            topics (List[str], optional): topics to slice. Defaults to None.
            slicer_func (SliceFuncType, optional): custom slicer function. Defaults to None
        Returns:
            int: total count of messages and frames sliced.
        """
        iter = reader.iter_frame_messages(start_timestamp_ms=start_timestamp_ms, 
                                          end_timestamp_ms=end_timestamp_ms, 
                                          topics=topics)
        frame_and_msg_count = 0
        for frame_or_msg in iter:
            if slicer_func:
                frame_or_msg = slicer_func(frame_or_msg)
            if frame_or_msg:
                if isinstance(frame_or_msg, Frame):
                    writer.write_frame(frame_or_msg)
                    frame_and_msg_count += 1 + len(frame_or_msg.messages)
                else:
                    writer.write_message(frame_or_msg)
                    frame_and_msg_count += 1
        return frame_and_msg_count
