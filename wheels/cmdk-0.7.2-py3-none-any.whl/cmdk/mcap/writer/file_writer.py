from os import PathLike
from typing import Union, BinaryIO, List

from google.protobuf.message import Message as ProtoBufMessage

from cmdk.common import exceptions
from cmdk.common.enums import CompressionType, SchemaEncoding
from cmdk.mcap.msg.message import Frame, Message
from cmdk.utils import mcap_handler, tools


class MCAPWriter:
    def __init__(
        self,
        stream: Union[str, PathLike, BinaryIO],
        chunk_size: int = 1024 * 1024 * 4,
        compression: Union[str, CompressionType] = CompressionType.NONE,
        enable_crc: bool = False
    ):
        if isinstance(stream, str) or isinstance(stream, PathLike):
            self.stream = open(tools.BucketPath(stream), "wb")
        self._handler = mcap_handler.MCAPWriteHandler(self.stream, chunk_size, compression, enable_crc)
        self._handler.start_write()
    
    def write_raw_message(self, topic: str, proto: ProtoBufMessage, gen_ts: int, data: List[bytes] = None, msg_id: int = None) -> None:
        """Write message (little message) by raw data.

        Args:
            gen_ts (int): generate timestamp, ms
            topic (str): topic name
            proto: proto message
            data (List[bytes]): data blocks

        """
        if self.closed:
            raise exceptions.ClosedError("Write of closed IO!")
        
        if frame := self._handler._topic_frame_map.get(topic):
            raise exceptions.InvalidMessageError(
                f"Topic {topic} registed with frame {frame}, should write frame directly!")
        
        self._handler.write_little_message(topic, proto, gen_ts, data, msg_id=msg_id)
        
    def write_raw_frame(self, topic: str, messages: List[dict], gen_ts: int, frame_id: int = None) -> None:
        """Write frame (big message) by raw data.
        
        Args:
            topic (str): frame topic name
            messages (List[dict]): little messages list, value is
                dict with keys 'topic', 'proto', 'gen_ts', 'data'(list of bytes), such as
                    {
                        "topic": "topic_name",
                        "proto": proto message,
                        "gen_ts": message timestamp ms,
                        "data": [bytes, bytes, ...]
                    }
            gen_ts (int): generate timestamp, ms
            frame_id (int): frame id

        """
        if self.closed:
            raise exceptions.ClosedError("Write of closed IO!")
        
        self._handler.write_frame(topic, gen_ts, messages, frame_id)
        
    def write_message(self, message: Message) -> None:
        """Write message (little message) by Message object.
        
        Args:
            message (Message): Message object
        
        """
        if self.closed:
            raise exceptions.ClosedError("Write of closed IO!")

        self.write_raw_message(
            message.topic, 
            message.proto, 
            message.gen_ts, 
            message.data, 
            msg_id=message._data_pb.msg_id if message._data_pb else None
        )

    def write_frame(self, frame: Frame) -> None:
        """Write frame (big message) by Frame object.

        Args:
            frame (Frame): Frame object

        """
        if self.closed:
            raise exceptions.ClosedError("Write of closed IO!")
        
        user_channel_id_map = {
            (_msg.topic, _msg.mcap_sequence): _msg.user_channel_id 
            for _msg in frame.proto.msg_list
        }
        messages = [
            {
                "topic": msg.topic,
                "proto": msg.proto, 
                "gen_ts": msg.gen_ts, 
                "data": msg.data,
                "msg_id": msg._data_pb.msg_id,
                "user_channel_id": user_channel_id_map.get((msg.topic, msg._seq), 0),
            } for msg in frame.messages
        ]
        extra = {
            "msg_id": frame.proto.msg_id,
            "frame_version": frame.proto.frame_version,
            "standardhead": frame.proto.standardhead,
        }
        self._handler.write_frame(frame.frame_topic, frame.gen_ts, messages, frame.frame_id, extra=extra)
    
    def write_json_message(self, topic: str, obj: dict, gen_ts: int) -> None:
        if self.closed:
            raise exceptions.ClosedError("Write of closed IO!")
        self._handler.write_raw_message(topic, obj, SchemaEncoding.JSON, gen_ts, gen_ts)

    def __enter__(self):
        return self

    def __exit__(self, *args, **kwargs):
        if not self.closed:
            self.close()

    def end_write(self):
        self._handler.end_write()

    def __del__(self):
        self.close()

    def close(self):
        self.end_write()
        self.stream.close()

    @property
    def closed(self) -> bool:
        return self.stream.closed
