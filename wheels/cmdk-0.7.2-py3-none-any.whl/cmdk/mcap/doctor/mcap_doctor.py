from enum import IntEnum
import logging
import io
import os
import sys

from cmdk.utils.mcap_handler import MCAPReadMixin, OperationCode
from cmdk.utils.msg_decoder import MSGCodecFactory, FRAME_MSG_NAME, HAD_MSG_NAME, ProtobufCodec


logger = logging.getLogger("cmdk")


class CheckStatusCode(IntEnum):
    SUCCESS = 0

    FILE_NOT_EXIST = 1
    IS_NOT_MCAP = 2

    NO_TAIL_SECTION = 10
    NO_SUMMARY_RECORD = 11
    NO_DATA_END_RECORD = 12

    BAD_SUMMARY_RECORD = 20
    BAD_CHUNK_RECORD = 21
    BAD_MESSAGE_INDEX_RECORD = 22
    BAD_METADATA_RECORD = 23
    BAD_MESSAGE_RECORD = 24
    BAD_SCHEMA_RECORD = 25

    MISSING_SCHEMA = 30
    MISMATCH_MSG_COUNT = 32
    MESSAGE_LOSS = 33

    @classmethod
    def _to_help(cls) -> str:
        items = []
        for name, _enum in cls.__members__.items():
            items.append(f"{_enum.value}:\t{name}")
        if sys.platform == "darwin":
            return "\n".join(items)
        return "\n\n".join(items)


class MCAPDoctor(MCAPReadMixin):
    def __init__(self, mcap_file):
        self.mcap_file = mcap_file
        self.mcap_size = 0
        self._fp = None
        self.summary = {}
        self.stream_summary = {
            "chunk_index": [],
            "channels": {},
            "schemas": {},
            "metadata": {},
        }
        self.footer = {}
        self.topic_decoder = {}
        self.error_codes = set()
        self.topic_seqs = {}
        self.frame_topic_seqs = {}
        self.msg_codec_factory = MSGCodecFactory()
        self.complete_chunks = set()
        self.meta_data_map = {}
        self._data_topic_check = {}
        self.logged_msg = set()
    
    def check_is_mcap(self):
        if not os.path.exists(self.mcap_file):
            self._err(f"{self.mcap_file} 文件不存在.")
            return CheckStatusCode.FILE_NOT_EXIST

        if os.path.isdir(self.mcap_file):
            self._err(f"{self.mcap_file} 是一个目录，不是文件.")
            return CheckStatusCode.IS_NOT_MCAP
        
        self.mcap_size = os.path.getsize(self.mcap_file)
        if self.mcap_size == 0:
            self._err("检测到空文件.")
            return CheckStatusCode.IS_NOT_MCAP
        
        self._fp = open(self.mcap_file, 'rb')
        if self._fp.read(len(self.MAGIC)) != self.MAGIC:
            return CheckStatusCode.IS_NOT_MCAP
        return CheckStatusCode.SUCCESS
    
    def check_valid_end(self):
        self._fp.seek(-37, io.SEEK_END)
        data = self._fp.read()
        footer_data = data[:29]
        magic = data[29:]
        if footer_data[0] != 0x02:
            self._err("文件缺少Footer, 该MCAP文件写过程可能出现中断.")
            return CheckStatusCode.NO_TAIL_SECTION
        try:
            footer_data, _ = self._read_footer_from_data(footer_data, 1)
            self.footer.update(footer_data)
        except Exception as e:
            self._err(f"文件Footer无法解析: {e}.")
            return CheckStatusCode.NO_TAIL_SECTION
        if self.footer["summary_start"] == 0:
            self._err("文件结尾缺少Summary记录.")
            return CheckStatusCode.NO_SUMMARY_RECORD
        if magic != self.MAGIC:
            self._err("文件结尾缺少MCAP标记, 该MCAP文件写过程可能出现中断.")
            return CheckStatusCode.NO_TAIL_SECTION
        return CheckStatusCode.SUCCESS

    def read_summary(self):
        self._fp.seek(self.footer["summary_start"], io.SEEK_SET)
        summary_size = self.footer["summary_offset_start"] - self.footer["summary_start"]
        summary_data = memoryview(self._fp.read(summary_size))
        try:
            summary, _ = self._read_summary_from_data(summary_data, length=summary_size)
            self.summary.update(summary)
            return CheckStatusCode.SUCCESS
        except Exception as e:
            self._err(f"Summary无法解析: {e}.")
            return CheckStatusCode.BAD_SUMMARY_RECORD
    
    def stream_check(self):
        self._fp.seek(len(self.MAGIC), io.SEEK_SET)
        has_end = False
        while True:
            try:
                opcode = self.read_1_io(self._fp)
            except Exception:
                if self._fp.tell() >= self.mcap_size:
                    self._warn(f"遇到EOF.")
                break
            if opcode == OperationCode.HEADER.value:
                self._read_header_from_io(self._fp)
            elif opcode == OperationCode.CHUNK.value:
                self.check_chunk()
            elif opcode == OperationCode.MESSAGE_INDEX.value:
                try:
                    msg_index = self._read_message_index_from_io(self._fp)
                    self.stream_summary["chunk_index"][-1]["message_indexes"].append(msg_index)
                except Exception as e:
                    self._err(f"解析Message Index失败: {e}.")
                    self.error_codes.add(CheckStatusCode.BAD_MESSAGE_INDEX_RECORD)
            elif opcode == OperationCode.METADATA.value:
                try:
                    metadata = self._read_metadata_from_io(self._fp)
                except Exception as e:
                    self._err(f"解析Metadata失败: {e}.")
                    self.error_codes.add(CheckStatusCode.BAD_METADATA_RECORD)
            elif opcode == OperationCode.DATA_END.value:
                has_end = True
                break
            elif opcode == OperationCode.MAGIC.value:
                break
            else:
                try:
                    self.read_unknown_io(self._fp)
                except Exception as e:
                    self._err(f"读取未知记录 {hex(opcode)} 失败: {e}.")
                    break
        
        if not has_end:
            self._err("文件缺失Data End.")
            self.error_codes.add(CheckStatusCode.NO_DATA_END_RECORD)
        
        for chunk in self.stream_summary["chunk_index"]:
            stream_msgs = chunk["stream_msgs"]
            indexed_msgs = sum(len(index["records"]) for index in chunk["message_indexes"])
            if stream_msgs != indexed_msgs:
                self._err(f"Chunk消息数量不匹配: offset {chunk['chunk_start_offset']}, {stream_msgs=} != {indexed_msgs=}.")
                self.error_codes.add(CheckStatusCode.MISMATCH_MSG_COUNT)
        
        topic_channels = {ch["topic"]: ch for ch in self.stream_summary["channels"].values()}
        for topic, channel in topic_channels.items():
            schema = self.stream_summary["schemas"][channel["schema_id"]]
            if schema["name"] not in (FRAME_MSG_NAME, HAD_MSG_NAME):
                data_topic = f"{topic}/data"
                data_channel = topic_channels.get(data_topic)
                if data_channel:
                    if self.stream_summary["schemas"][data_channel["schema_id"]]["name"] == HAD_MSG_NAME:
                        self.meta_data_map[topic] = data_topic
                        self._data_topic_check[data_topic] = False
        
        for meta_topic, data_topic in self.meta_data_map.items():
            meta_seqs = self.topic_seqs.get(meta_topic, set())
            data_seqs = self.topic_seqs.get(data_topic, set())
            
            if diff := list(meta_seqs - data_seqs):
                diff.sort()
                self._err(f"Meta topic对应的Data丢失: Topic: {meta_topic}, 丢失数量: {len(diff)}, Seq示例: {diff[:5]}.")
                self.error_codes.add(CheckStatusCode.MESSAGE_LOSS)
            
            if diff := list(data_seqs - meta_seqs):
                diff.sort()
                msg = f"Data topic对应的Meta丢失: Topic: {data_topic}, 丢失数量: {len(diff)}, Seq示例: {diff[:5]}."
                if self._data_topic_check.get(data_topic):
                    self.error_codes.add(CheckStatusCode.MESSAGE_LOSS)
                    self._err(msg)
                else:
                    self._warn(msg)
        misings = {}
        for topic, frames in self.frame_topic_seqs.items():
            for frame in frames:
                for sub_topic, seq in frame["msgs"]:
                    if seq not in self.topic_seqs.get(sub_topic, {}):
                        misings.setdefault(topic, {}).setdefault(frame["ts"], 0)
                        misings[topic][frame["ts"]] += 1
        for topic, ts_stat in misings.items():
            msg_count = sum(ts_stat.values())
            self._err(f"Frame子消息丢失: Topic: {topic}, 丢失Frame数: {len(ts_stat)}，丢失子消息数：{msg_count}，时间戳示例: {list(ts_stat)[:5]}.")
            self.error_codes.add(CheckStatusCode.MESSAGE_LOSS)

    def check_chunk(self):
        chunk_start_offset = self._fp.tell() - 1
        try:
            chunk = self._read_chunk_from_io(self._fp)
        except Exception as e:
            self._err(f"解析Chunk失败: {e}.")
            self.error_codes.add(CheckStatusCode.BAD_CHUNK_RECORD)
            return

        channels, schemas, msgs = self._read_records_from_chunk(chunk)
        chunk.pop("data")
        chunk.update({
            "chunk_start_offset": chunk_start_offset,
            "chunk_length": self._fp.tell() - chunk_start_offset,
            "stream_msgs": len(msgs),
            "message_indexes": []
        })
        self.stream_summary["chunk_index"].append(chunk)
        self.complete_chunks.add(chunk["chunk_start_offset"])
        
        schemas_map = {}
        for schema in schemas:
            schemas_map[schema["id"]] = schema
        if schemas_map:
            self.stream_summary["schemas"].update(schemas_map)

        channels_map = {}
        for channel in channels:
            channels_map[channel["id"]] = channel
            topic = channel["topic"]
            schema = self.stream_summary["schemas"][channel["schema_id"]]
            if schema["name"] == FRAME_MSG_NAME:
                self.frame_topic_seqs.setdefault(topic, [])
            try:
                self.msg_codec_factory.import_schema(topic, self.stream_summary["schemas"][channel["schema_id"]])
            except Exception:
                self._err(f"Topic初始化解码器失败: Topic: {channel['topic']}, Schema name: {schema['name']}.")
                self.error_codes.add(CheckStatusCode.BAD_SCHEMA_RECORD)
        if channels_map:
            self.stream_summary["channels"].update(channels_map)
        
        for msg in msgs:
            if msg["channel_id"] not in self.stream_summary["channels"]:
                self._err(f"消息的Channel未注册或写错: 时间戳: {msg['log_time']} Seq: {msg['sequence']} Channel ID: {msg['channel_id']}.")
                self.error_codes.add(CheckStatusCode.BAD_MESSAGE_RECORD)
                continue

            topic = self.stream_summary["channels"][msg["channel_id"]]["topic"]
      
            if topic not in self.frame_topic_seqs:
                self.topic_seqs.setdefault(topic, set()).add(msg["sequence"])
            try:
                decoder = self.msg_codec_factory.topic_codec[topic]
            except KeyError:
                _key = f"topic_schema_missing_{topic}"
                if _key not in self.logged_msg:
                    self._err(f"Topic解码器未定义, 无法解码消息: Topic: {topic}.")
                    self.logged_msg.add(_key)
                self.error_codes.add(CheckStatusCode.MISSING_SCHEMA)
                continue
            try:
                pb = decoder(msg["data"])
                if not isinstance(decoder, ProtobufCodec):
                    continue
                if topic in self._data_topic_check:
                    if len(pb.data_blocks) > 0:
                        self._data_topic_check[topic] = True
                elif topic in self.frame_topic_seqs:
                    self.frame_topic_seqs[topic].append({
                        "ts": msg["log_time"],
                        "seq": msg["sequence"],
                        "msgs": [
                            (msg.topic, msg.mcap_sequence)
                            for msg in pb.msg_list
                        ]
                    })
            except Exception as e:
                self._err(f"消息解码失败: Topic: {topic}, 时间戳: {msg['log_time']}.")
                self.error_codes.add(CheckStatusCode.BAD_MESSAGE_RECORD)

    def log(self, string, level=logging.ERROR, color="red"):
        if os.environ.get("_CMDK_RICH_LOGGING") == "1" and color:
            logger.log(level, f"[{color} bold]{string}", extra={"markup": True})
        else:
            logger.log(level, string)
    
    def _err(self, string):
        self.log(string, level=logging.ERROR, color="red")
    
    def _warn(self, string):
        self.log(string, level=logging.WARNING, color="yellow")
    
    def run_check(self):
        status = self.check_is_mcap()
        if status != CheckStatusCode.SUCCESS:
            self.error_codes.add(status)
            return self.error_codes
        
        status = self.check_valid_end()
        if status == CheckStatusCode.SUCCESS:
            status = self.read_summary()
            if status != CheckStatusCode.SUCCESS:
                self.error_codes.add(status)
            self.stream_check()
        else:
            self.error_codes.add(status)
        
        return self.error_codes
