from typing import Dict, List, Union, Any

from numpy.typing import NDArray
import numpy as np
from google.protobuf.message import Message as ProtoBufMessage

from cmdk.common import exceptions
from cmdk.utils import msg_decoder
from cmdk.utils.tools import r_property, rw_property


class Frame:
    def __init__(self, _raw_msg, _handle):
        self._raw_msg = _raw_msg
        self._handle = _handle

    @rw_property
    def messages(self) -> List[Union["Message"]]:
        return self._raw_msg[1:]
    
    @messages.set_validator
    def messages(self, msg_list: List["Message"]):
        assert isinstance(msg_list, list), f"Invalid msg_list type {type(msg_list)}!"
        for msg in msg_list:
            assert isinstance(msg, Message), f"Invalid msg type {type(msg)}!"
        return msg_list
    
    @r_property
    def topics(self) -> Dict[str, Union["Message"]]:
        return {msg.topic: msg for msg in self.messages}

    @r_property
    def proto(self) -> ProtoBufMessage:
        return self._handle.codec_factory.topic_codec[self.frame_topic]((self._raw_msg[0]["data"]))

    @rw_property
    def frame_id(self) -> int:
        return self.proto.frame_id

    @rw_property
    def frame_topic(self):
        return self._raw_msg[0]["topic"]

    @r_property
    def gen_ts(self) -> int:
        return self.proto.gen_ts
    
    @r_property
    def timestamp(self) -> int:
        return self.gen_ts
    
    @r_property
    def _seq(self):
        return self._raw_msg[0]["sequence"]

    @r_property
    def _log_time(self):
        return self._raw_msg[0]["log_time"]

    def __lt__(self, other: "Frame"):
        return self._log_time < other._log_time
    
    def __repr__(self):
        return f"<{self.__class__.__name__}: {self.frame_topic} [{self.gen_ts}]>"

    def __del__(self):
        del self._raw_msg


class Message:
    def __init__(self, raw_msg, handle, frame=None):
        self._raw_msg = raw_msg
        self._handle = handle
        self._frame = frame

    @rw_property
    def topic(self) -> str:
        return self._raw_msg["meta"]["topic"]
    
    @r_property
    def gen_ts(self) -> int:
        if self._data_pb:
            return self._data_pb.gen_ts
        return self._raw_msg["meta"]["log_time"]

    @r_property
    def done_ts(self) -> int:
        if self._data_pb:
            return self._data_pb.done_ts
        return self._raw_msg["meta"]["publish_time"]

    @r_property
    def timestamp(self) -> int:
        return self.gen_ts

    @r_property
    def payload(self) -> Any:
        """Returns the decoded payload of the message based on its encoding type(protobuf / ros2 / json).

        Returns:
            Union[ProtoBufMessage, dict, object]: The decoded payload, which can be a ProtoBufMessage,
            a dictionary for JSON encoded messages, or a raw object for unsupported encodings.
        """
        try:
            return self._handle.codec_factory.topic_codec[self.topic]((self._raw_msg["meta"]["data"]))
        except Exception as e:
            raise exceptions.DecodeError(
                f"Failed to parse message payload for {self.topic} (timestamp: {self._log_time}): {str(e)}") from None
    
    proto = payload   # 兼容老版本方式，推荐使用 payload 属性

    @rw_property
    def data(self) -> List[bytes]:
        if self._data_pb:
            return [block.data for block in self._data_pb.data_blocks]
        return []

    @r_property
    def _data_pb(self):
        if "had" in self._raw_msg:
            return self._handle.codec_factory.topic_codec[self._raw_msg["had"]["topic"]](
                self._raw_msg["had"]["data"])

    def __lt__(self, other: "Message") -> bool:
        return self._log_time < other._log_time

    def __repr__(self) -> str:
        return f"<{self.__class__.__name__}: {self.topic} {self.gen_ts}>"

    @r_property
    def _seq(self):
        return self._raw_msg["meta"]["sequence"]

    @r_property
    def _log_time(self):
        return self._raw_msg["meta"]["log_time"]
    
    def __del__(self):
        del self._frame


class ImageMessage(Message):
    """Carizon Image Message class."""
    def to_ndarray(self, format="bgr24") -> NDArray[np.uint8]:
        """Converts the message data into a NumPy array representation of an image.
            format (str, optional): The desired format of the output image. Defaults to "bgr24".
                Supported formats:
                    - "rgb24": RGB format.
                    - "bgr24": BGR format.
                    - "gray": Grayscale format.
                    - "yuv420p": YUV420 planar format.
                    - "yuv444p": YUV444 planar format.
            NDArray[np.uint8]: A NumPy array containing the image data in the specified format.

        """
        if not self.data:
            raise exceptions.DecodeError(f"No image data available for topic {self.topic} at timestamp {self.gen_ts}.")
        codec = self._handle.image_decoders[self.topic]
        return codec.to_ndarray(self.data[0], format=format)

    def to_jpg(self, quality: int = 95) -> bytes:
        """Converts the current object to a JPEG image representation.
        
        Args:
            quality (int, optional): The quality of the JPEG image, ranging from 0 to 100. 
                Higher values indicate better quality. Defaults to 95.
        Returns:
            bytes: The encoded JPEG image as a byte array.
        """
        if not self.data:
            raise exceptions.DecodeError(f"No image data available for topic {self.topic} at timestamp {self.gen_ts}.")
        codec = self._handle.image_decoders[self.topic]
        return codec.to_jpg(self.data[0], quality=quality)


class LidarMessage(Message):
    """Carizon Lidar Message class."""
    def to_ndarray(self) -> NDArray[np.float32]:
        """Converts the lidar message data into a NumPy ndarray.

        Returns:
            NDArray[np.float32]: A NumPy array containing the decoded lidar data.
        """
        if not self.data:
            raise exceptions.DecodeError(f"No lidar data available for topic {self.topic} at timestamp {self.gen_ts}.")
        return msg_decoder.LidarDecoder.decode_data(
            self.data[0], 
            points=self.proto.lidar_data_info.point_count,
            pcd_type=self.proto.lidar_data_info.pcd_type,
            scale=self.proto.lidar_data_info.scale
        )

    def to_pcd(self, encoding: str = "binary") -> bytes:
        """Converts the lidar message data into PCD format.

        Args:
            encoding (str, optional): The encoding format for the PCD file. 
                Supported values are "binary" and "ascii". Defaults to "binary".

        Returns:
            bytes: The PCD formatted data as a byte array.
        """
        return msg_decoder.LidarDecoder.to_pcd(self.to_ndarray(), encoding=encoding)


class FoxgloveCompressedVideoMessage(ImageMessage): 
    """Foxglove Compressed Video Message class."""
    @rw_property
    def data(self) -> List[bytes]:
        return [self.proto.data]
