import numpy as np
from numpy.typing import NDArray
from google.protobuf.json_format import MessageToDict

class ExtractFrame:
    def __init__(self, topic, proto, timestamp):
        self.topic = topic
        self.proto = proto
        self.timestamp = timestamp

    def to_dict(self) -> dict:
        return MessageToDict(self.proto, preserving_proto_field_name=True)


class CameraExtractFrame(ExtractFrame):
    def __init__(self, topic, proto, timestamp, decoder):
        super().__init__(topic, proto, timestamp)
        self.decoder = decoder
    
    def to_array(self, format) -> NDArray[np.int32]:
        pass
    
    def to_jpg(self, quality: int = 95) -> bytes:
        pass


class LidarExtractFrame(ExtractFrame):
    def to_array(self) -> NDArray[np.float32]:
        pass