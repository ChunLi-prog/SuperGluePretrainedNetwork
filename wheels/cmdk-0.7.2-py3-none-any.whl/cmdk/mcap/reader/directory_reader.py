from concurrent import futures as concurrent
from functools import cached_property
import heapq
from os import PathLike, environ
from typing import List, Dict, Iterator, Union
import warnings

from cmdk import get_logger
from cmdk.common import exceptions, settings
from cmdk.common.warning import CMDKWarning
from cmdk.mcap import MCAPReader, Frame, Message, ImageMessage, LidarMessage
from cmdk.utils.tools import BucketPath, r_property


logger = get_logger()


class DirectoryReader:
    """
    MCAP Directory Reader.
    
    >>> with DirectoryReader("/path/to/mcap_directory") as reader:
    ...     if reader.check_valid():
    ...         for msg in reader.iter_messages(topics=["image-/dc/adas_1"]):
    ...             process(msg)
    """
    def __init__(self, directory: Union[str, PathLike]):
        self.dir = BucketPath(directory)
        if self.dir.is_dir() is False:
            raise exceptions.InvalidFrameError(f"{directory} is not a valid directory")
        self.errors = {}
        if environ.get(settings.DISABLE_MCAP_OBSTRUCT_ENV) != "1":
            if not self.check_valid():
                raise exceptions.MCAPObstructedError(
                    f"Some MCAP files in directory {directory} are invalid: {self.errors}")

    def check_valid(self) -> bool:
        """Check if the directory all MCAP files are valid.

        Returns:
            bool: check result.
        """
        if not self._readers:
            logger.error(f"No valid MCAP files found in directory: {self.dir}")
            return False
        return not self.errors

    @r_property
    def topics(self) -> List[str]:
        """Gets all topics from all MCAP files in the directory.

        Returns:
            List[str]: topic list.
        """
        topic_set = set()
        for topic_count in self._readers.values():
            topic_set.update(topic_count)
        return list(topic_set)
    
    @r_property
    def topics_message_count(self) -> Dict[str, int]:
        """Retrieves the count of messages for each topic across all MCAP files in the directory.

        Returns:
            Dict[str, int]: A dictionary where the keys are topic names and the values are the message counts.
        """
        topic_msg_count = {}
        for topic_count in self._readers.values():
            topic_msg_count.update(topic_count)
        return topic_msg_count

    def get_start_timestamp(self) -> int:
        """Retrieves the first message timestamp across all MCAP files in the directory.

        Returns:
            int: The start timestamp (ms).
        """
        start_timestamps = []
        for reader in self._readers:
            if timestamp := reader.get_start_timestamp():
                start_timestamps.append(timestamp)
        return min(start_timestamps) if start_timestamps else 0

    def get_end_timestamp(self) -> int:
        """Retrieves the end message timestamp across all MCAP files in the directory.

        Returns:
            int: The end timestamp (ms).
        """
        end_timestamps = [reader.get_end_timestamp() for reader in self._readers]
        return max(end_timestamps) if end_timestamps else 0

    def iter_messages(
        self, 
        start_timestamp_ms=None, 
        end_timestamp_ms=None, 
        topics=None
    ) -> Iterator[Dict[str, Union[Message, ImageMessage, LidarMessage]]]:
        """Iterate over messages within a specified time range and topics across all MCAP files in the directory.
    
        警告: 该方法小消息会按照topic去重，由于可能会存在大消息包含多条重复topic的小消息的情形，会导致部分小消息无法读到。
            建议使用iter_messages_list方法或iter_frame_messages方法。
              
        Args:
            start_timestamp_ms (int, optional): start timestamp in milliseconds. Defaults to None.
            end_timestamp_ms (int, optional): end timestamp in milliseconds. Defaults to None.
            topics (str, optional): topic list to filter messages. Defaults to None.

        Raises:
            exceptions.ClosedError: Raised if the reader is closed

        Yields:
            Iterator[Dict[str, Union[Message, ImageMessage, LidarMessage]]]: An iterator over messages.
        """
        for frame_or_msg in self.iter_frame_messages(start_timestamp_ms, end_timestamp_ms, topics):
            if isinstance(frame_or_msg, Frame):
                yield {msg.topic: msg for msg in frame_or_msg.messages}
            else:
                yield {frame_or_msg.topic: frame_or_msg}

    def iter_messages_list(
        self, 
        start_timestamp_ms=None, 
        end_timestamp_ms=None, 
        topics=None
    ) -> Iterator[List[Union[Message, LidarMessage, ImageMessage]]]:
        """Iterate over messages within a specified time range and topics across all MCAP files in the directory.

        Args:
            start_timestamp_ms (int, optional): start timestamp in milliseconds. Defaults to None.
            end_timestamp_ms (int, optional): end timestamp in milliseconds. Defaults to None.
            topics (str, optional): topic list to filter messages. Defaults to None.

        Raises:
            exceptions.ClosedError: Raised if the reader is closed

        Yields:
            Iterator[List[Union[Message, LidarMessage, ImageMessage]]]: An iterator over messages.
        """
        for frame_or_msg in self.iter_frame_messages(start_timestamp_ms, end_timestamp_ms, topics):
            if isinstance(frame_or_msg, Frame):
                yield frame_or_msg.messages
            else:
                yield [frame_or_msg]

    def iter_frame_messages(
        self, 
        start_timestamp_ms=None, 
        end_timestamp_ms=None, 
        topics=None
    ) -> Iterator[Union[Frame, Message, LidarMessage, ImageMessage]]:
        """Iterate over messages within a specified time range and topics across all MCAP files in the directory.

        Args:
            start_timestamp_ms (int, optional): start timestamp in milliseconds. Defaults to None.
            end_timestamp_ms (int, optional): end timestamp in milliseconds. Defaults to None.
            topics (str, optional): topic list to filter messages. Defaults to None.

        Raises:
            exceptions.ClosedError: Raised if the reader is closed

        Yields:
            Iterator[Union[Frame, Message, LidarMessage, ImageMessage]]: An iterator over frame/messages.
        """
        if self.closed:
            raise exceptions.ClosedError("Read of closed IO!")
        
        iters = []
        if topics:
            topics = set(topics)
            readers = [
                reader for reader, topic_count in self._readers.items() if not topics.isdisjoint(topic_count)
            ]
        else:
            readers = self._readers
        iters = [
            reader.iter_frame_messages(
                start_timestamp_ms=start_timestamp_ms,
                end_timestamp_ms=end_timestamp_ms,
                topics=topics
            ) for reader in readers
        ]
        fm_heap = []
        for idx, fm_iter in enumerate(iters):
            try:
                fm = next(fm_iter)
                fm_heap.append([fm, idx, fm_iter])
            except StopIteration:
                pass
        heapq.heapify(fm_heap)
        while len(fm_heap) > 1:
            try:
                while True:
                    fm, idx, fm_iter = s = fm_heap[0]
                    yield fm
                    s[0] = next(fm_iter)
                    heapq.heapreplace(fm_heap, s)
            except StopIteration:
                heapq.heappop(fm_heap)
        
        if fm_heap:
            fm, idx, fm_iter = fm_heap[0]
            yield fm
            yield from fm_iter

    @cached_property
    def _readers(self) -> Dict[MCAPReader, Dict[str, int]]:
        def _create_reader(path):
            try:
                return MCAPReader(path)
            except Exception as e:
                if environ.get(settings.DISABLE_MCAP_OBSTRUCT_ENV) == "1":
                    warnings.warn(f"Failed to read {path.name}. Error: {e}!", CMDKWarning)
                self.errors[path.name] = str(e)
        with concurrent.ThreadPoolExecutor(max_workers=8) as executor:
            return {
                reader: {topic: count for topic, count in reader.topics_message_count.items() if count}
                for reader in executor.map(_create_reader, self.dir.glob("*.mcap")) if reader
            }

    def __enter__(self):
        return self
    
    def __exit__(self, exc_type, exc_value, traceback):
        self.close()
    
    @property
    def closed(self) -> bool:
        if not self._readers:
            return False
        return all([reader.closed for reader in self._readers])
    
    def close(self):
        for reader in self._readers:
            reader.close()
