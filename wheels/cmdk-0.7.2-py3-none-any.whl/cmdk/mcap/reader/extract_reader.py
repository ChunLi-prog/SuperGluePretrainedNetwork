import copy
from dataclasses import dataclass
from typing import Any, Iterator, Callable, Union
import io

import zstandard
import msgpack
import numpy as np

from cmdk.utils.mss_server import mss_server_cli
from cmdk.common import exceptions
from cmdk.utils import msg_decoder, mcap_handler
from cmdk.utils.mcap_obstructer import obstructer


@dataclass
class Frame:
    timestamp_ms: int
    data: Any
    format: str


class FrameExtractReader:
    """Frame extract reader.

    >>> reader = FrameExtractReader.from_clip_topics(vehicle_id="...",
    >>>                                              start_timestamp_ms=... 
    >>>                                              end_timestamp_ms=...
    >>>                                              topics=[...]
    >>>                                              )
    >>> reader.open(timestamp_ms=..., topic=...)
    """
    @classmethod
    def from_clip_topics(
            cls, 
            vehicle_id: str, 
            start_timestamp_ms: int, 
            end_timestamp_ms: int, 
            topics: list,
        ):
        """Create a reader that reads frames using vehicle number + clip + topic.

        Args:
            vehicle_id (str): vehicle id
            start_timestamp_ms (int): start timestamp (ms)
            end_timestamp_ms (int): end timestamp (ms)
            topics (list): filter topics,

        Returns:
            FrameExtractReader
        """
        index = mss_server_cli.get_clip_info(vehicle_id, start_timestamp_ms, end_timestamp_ms, topics)
        return cls(index)

    @classmethod
    def from_index(cls, index_id: str):
        """Create a reader from extracted index.

        Args:
            index_id (str): extracted index id.

        Returns:
            FrameExtractReader
        """
        index = mss_server_cli.get_ex_index_v2(index_id)
        return cls(index)
    
    @classmethod
    def from_index_file(cls, index_path: str):
        """Create a reader from extracted index.

        Args:
            index_path (str): extracted index file.

        Returns:
            FrameExtractReader
        """
        with open(index_path, "rb") as fp:
            index = msgpack.unpackb(fp.read())
        return cls(index)

    @classmethod
    def all_topics(
            cls,
            vehicle_id: str,
            start_timestamp_ms: int,
            end_timestamp_ms: int
        ) -> set:
        topics = set()
        for info in mss_server_cli.search_clips(vehicle_id, start_timestamp_ms, end_timestamp_ms):
            for mcap_info in info.get("mcap_info", {}).values():
                topics.update(mcap_info.get("topics", []))
        return topics

    def list(self, topics=None) -> dict:
        """List all frames based on the topics.

        Args:
            topics (list, optional): topics to be filtered.

        Returns:
            dict: topics frames.
                {
                    'topic-A': [
                        timestamp_ms_1,
                        timestamp_ms_2
                    ]
                    'topic-B': [
                        timestamp_ms_3,
                    ]
                }
        """
        result = {}
        for topic, info in self._index["topics"].items():
            frames = []
            if topics and topic not in topics:
                continue
            for mcap_info in info["mcaps"]:
                frames.extend([f[0] for f in mcap_info["frames"]])
            frames.sort()
            result[topic] = frames
        return result
        
    def filter_dump(self, filter_func: Callable, username=None, description=None) -> str:
        """Filter frame index and save the filtered results to the index service.

        Args:
            filter_func (Callable): filter function, takes the topic frame result as input for filtering, 
                and returns the same structure.
            username (str, optional): the index owner.
            description (str, optional): description of the index.

        Returns:
            str: index id.
        """
        filter_result = filter_func(self.list())
        assert isinstance(filter_result, dict)
        start_ts = 0
        end_ts = 0
        for key, value in filter_result.items():
            assert isinstance(key, str)
            assert isinstance(value, list)
            if value:
                if start_ts:
                    start_ts = min(start_ts, min(value))
                end_ts = max(end_ts, max(value))
        index_result = {
            "vehicle_id": self._index["vehicle_id"],
            "start_ts": start_ts,
            "end_ts": end_ts,
        }
        topics = {}
        for topic, topic_info in self._index["topics"].items():
            if topic not in filter_result:
                continue
            new_topic_info = {
                "schema": topic_info["schema"],
                "topic_type": topic_info["topic_type"],
            }
            if "idr_frame" in topic_info:
                new_topic_info["idr_frame"] = topic_info["idr_frame"]
            if "lidar_info" in topic_info:
                new_topic_info["lidar_info"] = topic_info["lidar_info"]
            mcaps = []
            for mcap_info in topic_info["mcaps"]:
                filter_frames = []
                for frame in filter_result[topic]:
                    if frame in self._frames[topic]:
                        filter_frames.append(self._frames[topic][frame][1])
                filter_frames.sort(key=lambda v: v[0])
                chunks = copy.deepcopy(mcap_info["chunks"])
                for c in chunks:
                    c.pop("frames", None)
                mcaps.append({
                    "mcap_file": mcap_info["mcap_file"],
                    "frames": filter_frames,
                    "chunks": chunks
                })
            new_topic_info["mcaps"] = mcaps
            topics[topic] = new_topic_info
        index_result["topics"] = topics
        index_id = mss_server_cli.upload_ex_index(index_result, username=username, description=description)
        return index_id
    
    def open(self, timestamp_ms, topic) -> Frame:
        """Read frame data.

        Args:
            timestamp_ms (int): timestamp(ms).
            topic (str): topic.

        Raises:
            exceptions.ResourceNotFound: topic or timestamp not found.

        Returns:
            Frame: frame info.
        """
        if topic not in self._index["topics"]:
            raise exceptions.ResourceNotFound(f"Not found topic {topic} in {list(self._index['topics'])}!")
        file_type = self.get_type_by_topic(topic)
        frame = self._frames[topic].get(timestamp_ms)
        if not frame:
            raise exceptions.ResourceNotFound(f"Not found {timestamp_ms} in topic {topic} index!")
        
        with open(frame[0], "rb") as fp:
            if frame[2]["compression"]:
                fp.seek(frame[2]["offset"], 0)
                data = fp.read(frame[2]["size"])
                data = zstandard.decompress(data, frame[2]["uncompressed_size"])
                msg_data = data[frame[1][1]:frame[1][1] + frame[1][2]]
            else:
                fp.seek(frame[1][1], 0)
                msg_data = fp.read(frame[1][2])
        
        dc = self._topic_decoder[topic]
        real_data = dc.decode(msg_data)
        return Frame(timestamp_ms=timestamp_ms, data=real_data, format=file_type)
    
    def iter(self, topic, start_timestamp_ms=None, end_timestamp_ms=None) -> Iterator[Frame]:
        """Read frame info iterable.

        Args:
            topic (str): topic.
            start_timestamp_ms (int, optional): start timestamp(ms).
            end_timestamp_ms (int, optional): end timestamp(ms).

        Raises:
            exceptions.ResourceNotFound: topic not found.

        Yields:
            Iterator[Frame]: frame info iterator.
        """
        topic_info = self._index["topics"].get(topic)
        if not topic_info:
            raise exceptions.ResourceNotFound(f"Not found topic {topic}!")
        dc = self._topic_decoder[topic]
        file_type = self.get_type_by_topic(topic)

        if start_timestamp_ms:
            start_timestamp_ms = max(start_timestamp_ms, self._index["start_ts"])
        else:
            start_timestamp_ms = self._index["start_ts"]

        if end_timestamp_ms:
            end_timestamp_ms = min(end_timestamp_ms, self._index["end_ts"])
        else:
            end_timestamp_ms = self._index["end_ts"]

        for mcap_info in topic_info["mcaps"]:
            with open(self._get_path(mcap_info["mcap_file"]), "rb") as fp:
                for chunk_info in mcap_info["chunks"]:
                    if self.is_chunk_not_overlap(chunk_info, start_timestamp_ms, end_timestamp_ms):
                        continue
                    if chunk_info["compression"]:
                        fp.seek(chunk_info["offset"], 0)
                        data = fp.read(chunk_info["size"])
                        data = zstandard.decompress(data, chunk_info["uncompressed_size"])
                        for frame in chunk_info.get("frames", []):
                            if self.is_ts_not_overlap(frame[0], start_timestamp_ms, end_timestamp_ms):
                                continue
                            msg_data = data[frame[1]:frame[1] + frame[2]]
                            real_data = dc.decode(msg_data)
                            yield Frame(timestamp_ms=frame[0], data=real_data, format=file_type)
                    else:
                        for frame in chunk_info.get("frames", []):
                            if self.is_ts_not_overlap(frame[0], start_timestamp_ms, end_timestamp_ms):
                                continue
                            fp.seek(frame[1], 0)
                            msg_data = fp.read(frame[2])
                            real_data = dc.decode(msg_data)
                            yield Frame(timestamp_ms=frame[0], data=real_data, format=file_type)
    
    @staticmethod
    def is_ts_not_overlap(target: int, start_ts: int = None, end_ts: int = None) -> bool:
        return target < start_ts or target > end_ts

    @staticmethod
    def is_chunk_not_overlap(chunk: dict, start_ts: int, end_ts: int) -> bool:
        return end_ts < chunk["start_ts"] or chunk["end_ts"] < start_ts

    def get_type_by_topic(self, topic: str):
        if topic.startswith("image/"):
            return "jpg"
        elif topic.startswith("hesai/"):
            return "npy"
        else:
            return "dict"

    def _init_decorder(self):
        self._topic_decoder = {}
        for topic, topic_info in self._index["topics"].items():
            t_type = topic_info["topic_type"]
            if t_type == "image/data":
                _i_decoder = msg_decoder.CameraProtoCodec(self._proto_decoder_fac.topic_codec[topic])
                idr_info = topic_info["idr_frame"]
                chunk = idr_info["chunk"]
                frame = idr_info["frame"]
                with open(self._get_path(idr_info["mcap_file"]), "rb") as fp:
                    if chunk["compression"]:
                        fp.seek(chunk["offset"], 0)
                        data = fp.read(chunk["size"])
                        data = zstandard.decompress(data, chunk["uncompressed_size"])
                        msg_data = data[frame[1]:frame[1] + frame[2]]
                    else:
                        fp.seek(frame[1], 0)
                        msg_data = fp.read(frame[2])
                    codec = self._proto_decoder_fac.topic_codec[topic]
                    pb = codec(msg_data)
                    _i_decoder.set_extra(pb.data_blocks[0].data)
                    self._topic_decoder[topic] = _i_decoder
            elif t_type == "lidar/data":
                self._topic_decoder[topic] = msg_decoder.LidarDecoder(
                    pb_codec=self._proto_decoder_fac.topic_codec[topic],
                    max_points=topic_info["lidar_info"]["max_point_count"],
                    pcd_type=topic_info["lidar_info"]["pcd_type"],
                    scale=topic_info["lidar_info"]["scale"],
                )
            else:
                self._topic_decoder[topic] = self._proto_decoder_fac.topic_codec[topic]

    def __init__(self, index):
        self._index = index
        self._vehicle = self._index["vehicle_id"]
        self._proto_decoder_fac = msg_decoder.MSGCodecFactory()
        frames = {}
        for topic, topic_info in self._index["topics"].items():
            self._proto_decoder_fac.import_schema(topic, topic_info["schema"])
            frames[topic] = {}
            for mcap_info in topic_info["mcaps"]:
                full_path = self._get_path(mcap_info["mcap_file"])
                obstructer.check_from_reader(full_path)
                chunks = mcap_info["chunks"]
                for frame in mcap_info["frames"]:
                    _frame = (full_path, frame, chunks[frame[3]].copy())
                    chunks[frame[3]].setdefault("frames", []).append(frame)
                    frames[topic][frame[0]] = _frame

        self._frames = frames
        self._init_decorder()
    
    @staticmethod
    def _get_path(bucket_file):
        return "/horizon-bucket/" + bucket_file

    def __getstate__(self):
        state = self.__dict__.copy()
        del state['_proto_decoder_fac']
        del state['_topic_decoder']
        return state

    def __setstate__(self, state):
        self.__dict__.update(state)
        self._proto_decoder_fac = msg_decoder.MSGCodecFactory()
        for topic, topic_info in self._index["topics"].items():
            self._proto_decoder_fac.import_schema(topic, topic_info["schema"])
        self._init_decorder()


class ExtractData:    
    @classmethod
    def _extract_jpg(cls, 
                     mcap_file: str, 
                     chunk_index_info: dict, 
                     frame_index_info: dict, 
                     timestamp_ms: int, 
                     topic: str,
                     match_mode="nearby",
                     quality = 95,
                     resize_scale = 100,
                     resize_width = None) -> Union[bytes, None]:
        """Extracts a JPEG image from an MCAP file based on the provided parameters.
        
        Args:
            mcap_file (str): Path to the MCAP file.
            chunk_index_info (dict): Information about the chunks in the MCAP file, 
            frame_index_info (dict): Information about the frames in the MCAP file, 
            timestamp_ms (int): The timestamp in milliseconds to locate the desired frame.
            topic (str): The topic associated with the frame data.
            match_mode (str, optional): The mode for matching the frame based on the 
                timestamp. Defaults to "nearby".
            quality (int, optional): The quality of the jpg quality. Defaults to 95.
            resize_scale (int, optional): Resize the frame dimensions by scale. Defaults to 100.
            resize_width (int, optional): Resize the frame dimensions by width. Defaults to None.

        Returns:
            bytes: The decoded JPEG image data.
        
        Raises:.
            ValueError: If the decoding process encounters invalid data.

        """
        if topic not in frame_index_info:
            raise exceptions.ResourceNotFound(f"Not found topic {topic}!")
        
        frame = cls._search_frame_info(frame_index_info[topic]["frames"], timestamp_ms, match_mode=match_mode)
                
        idr = frame_index_info[topic]["idr_frame"]
        
        msg_decoder.default_codec_factory.import_schema(topic, chunk_index_info["schemas"][topic])
        
        chunk = chunk_index_info["chunks"][frame[3]]

        with open(mcap_file, "rb")as fp:
            if chunk[4]:
                fp.seek(chunk[2], 0)
                data = fp.read(chunk[3])
                data = memoryview(mcap_handler.MCAPReadHandler.chunk_decompress(data, chunk[4], chunk[5]))
                msg_raw = data[frame[1]:frame[1] + frame[2]]
            else:
                fp.seek(frame[1])
                msg_raw = fp.read(frame[2])
            need_idr = True
            msg_data = msg_decoder.default_codec_factory(msg_raw, topic).data_blocks[0].data
            if msg_data[4] & 0x7e == 0x40:
                need_idr = False
            decoder = msg_decoder.CameraCodec()
            if need_idr:
                idr_chunk = chunk_index_info["chunks"][idr[3]]
                if idr_chunk[4]:
                    fp.seek(idr_chunk[2], 0)
                    data = fp.read(idr_chunk[3])
                    data = memoryview(mcap_handler.MCAPReadHandler.chunk_decompress(data, idr_chunk[4], idr_chunk[5]))
                    msg_raw = data[idr[1]:idr[1] + idr[2]]
                else:
                    fp.seek(idr[1])
                    msg_raw = fp.read(idr[2])
                idr_msg_data = msg_decoder.default_codec_factory(msg_raw, topic).data_blocks[0].data
                decoder.set_extra(idr_msg_data)
        return decoder.array_to_jpg(
            decoder.to_ndarray(msg_data), quality=quality, resize_scale=resize_scale, resize_width=resize_width)

    @classmethod
    def _extract_lidar(cls,
                       mcap_file: str, 
                       chunk_index_info: dict, 
                       frame_index_info: dict, 
                       timestamp_ms: int, 
                       topic: str,
                       match_mode="nearby",
                       format="pcd") -> Union[bytes, None]:
        frame = cls._search_frame_info(frame_index_info[topic]["frames"], timestamp_ms, match_mode=match_mode)
        lidar_info = frame_index_info[topic]["lidar_info"]
        msg_decoder.default_codec_factory.import_schema(topic, chunk_index_info["schemas"][topic])
        chunk = chunk_index_info["chunks"][frame[3]]
        with open(mcap_file, "rb")as fp:
            if chunk[4]:
                fp.seek(chunk[2], 0)
                data = fp.read(chunk[3])
                data = memoryview(mcap_handler.MCAPReadHandler.chunk_decompress(data, chunk[4], chunk[5]))
                msg_raw = data[frame[1]:frame[1] + frame[2]]
            else:
                fp.seek(frame[1])
                msg_raw = fp.read(frame[2])
        decoder = msg_decoder.LidarDecoder(msg_decoder.default_codec_factory.topic_codec[topic],
                                           max_points=lidar_info["max_point_count"],
                                           pcd_type=lidar_info["pcd_type"],
                                           scale=lidar_info["scale"])
        arr = decoder.decode(msg_raw)
        if format == "array":
            return arr
        elif format == "npy":
            with io.BytesIO() as bio:
                np.save(bio, arr)
                return bio.getvalue()
        elif format == "pcd":
            return decoder.to_pcd(arr)

    @staticmethod
    def _search_frame_info(frames, timestamp_ms, match_mode="nearby"):
        if timestamp_ms < (frames[0][0] - 1000) or timestamp_ms > (frames[-1][0] + 1000):
            raise exceptions.ResourceNotFound(f"Search {timestamp_ms} out of range!")
        
        length = len(frames)
        left, right = 0, length
        while left < right:
            mid = (left + right) // 2
            if frames[mid][0] < timestamp_ms:
                left = mid + 1
            else:
                right = mid
        
        if right == length:
            return frames[right - 1]
        elif right == 0:
            return frames[right]

        if match_mode == "nearby":
            return (frames[right - 1] 
                    if timestamp_ms - frames[right - 1][0] < frames[right][0] - timestamp_ms 
                    else frames[right])
        elif match_mode == "floor":
            return frames[right] if frames[right][0] == timestamp_ms else frames[right - 1]
        elif match_mode == "ceiling":
            return frames[right]
        else:
            raise exceptions.UnsupportedError(f"Unknown match mode {match_mode}!")
