from functools import cached_property
from os import PathLike
from typing import List, Dict, Iterator, Union, Optional

from cmdk.common import exceptions
from cmdk.mcap.msg.message import Frame, Message, ImageMessage, LidarMessage
from cmdk.utils import mcap_handler, tools
from cmdk.utils.mcap_obstructer import obstructer


class MCAPReader:
    def __init__(
        self, 
        mcap_path: Union[str, PathLike]
    ):
        mcap_path = tools.BucketPath(mcap_path)
        
        obstructer.check_from_reader(mcap_path)
        
        self._fp = open(mcap_path, mode="rb")
        self._handler = mcap_handler.MCAPReadHandler(self._fp, mcap_path)

    @cached_property
    def topics(self) -> List[str]:
        """Gets all topics.

        Returns:
            List[str]: topic list.
        """
        return [topic for topic, info in self._handler._all_topics.items() if info["type"] != "had"]

    @cached_property
    def topics_message_count(self) -> Dict[str, int]:
        """Retrieves the count of messages for each topic.

        Returns:
            Dict[str, int]: A dictionary where the keys are topic names and the values are the message counts.
        """
        return {topic: info["message_count"]
                for topic, info in self._handler._all_topics.items() if info["type"] != "had"}

    def iter_messages(
        self, 
        start_timestamp_ms: int = None, 
        end_timestamp_ms: int = None, 
        topics: List[str] = None
    ) -> Iterator[Dict[str, Union[Message, LidarMessage, ImageMessage]]]:
        """Iterate over messages within a specified time range and topics.

        警告: 该方法小消息会按照topic去重，由于可能会存在大消息包含多条重复topic的小消息的情形，会导致部分小消息无法读到。
              建议使用iter_messages_list方法或iter_frame_messages方法。
        
        Args:
            start_timestamp_ms (int, optional): The start timestamp in milliseconds.
            end_timestamp_ms (int, optional): The end timestamp in milliseconds.
            topics (List[str], optional): A list of topic names to filter messages.
        Raises:
            ValueError:  Raised if the reader is closed

        Yields:
            Iterator[Dict[str, Union[Message, LidarMessage, ImageMessage]]]: 
                An iterator over dictionaries mapping topic names to Message objects.
        """
        if self.closed:
            raise exceptions.ClosedError("Read of closed IO!")
        for msg in self._handler.iter_messages(start_timestamp_ms, end_timestamp_ms, topics):
            if isinstance(msg, Frame):
                yield msg.topics
            else:
                yield {msg.topic: msg}

    def iter_frame_messages(
        self, 
        start_timestamp_ms: int = None, 
        end_timestamp_ms: int = None, 
        topics: List[str] = None
    ) -> Iterator[Union[Frame, Message, LidarMessage, ImageMessage]]:
        """Iterate over frames/messages within a specified time range and topics.

        Args:
            start_timestamp_ms (int, optional): The start timestamp in milliseconds.
            end_timestamp_ms (int, optional): The end timestamp in milliseconds.
            topics (List[str], optional): A list of topic names to filter messages.
        Raises:
            ValueError:  Raised if the reader is closed

        Yields:
            Iterator[Union[Frame, Message, LidarMessage, ImageMessage]]: An iterator over frames/messages.
        """
        if self.closed:
            raise exceptions.ClosedError("Read of closed IO!")
        return self._handler.iter_messages(start_timestamp_ms, end_timestamp_ms, topics)

    def iter_messages_list(
        self, 
        start_timestamp_ms: int = None, 
        end_timestamp_ms: int = None, 
        topics: List[str] = None
    ) -> Iterator[List[Union[Message, LidarMessage, ImageMessage]]]:
        """Iterate over messages within a specified time range and topics.

        Args:
            start_timestamp_ms (int, optional): The start timestamp in milliseconds.
            end_timestamp_ms (int, optional): The end timestamp in milliseconds.
            topics (List[str], optional): A list of topic names to filter messages.
        Raises:
            ValueError:  Raised if the reader is closed

        Yields:
            Iterator[List[Union[Message, LidarMessage, ImageMessage]]]: An iterator over lists of messages.
        """
        if self.closed:
            raise exceptions.ClosedError("Read of closed IO!")
        for msg in self._handler.iter_messages(start_timestamp_ms, end_timestamp_ms, topics):
            if isinstance(msg, Frame):
                yield msg.messages
            else:
                yield [msg]

    def get_start_timestamp(self) -> int:
        """Retrieves the first message timestamp.

        Returns:
            int: The start timestamp (ms).
        """
        return self._handler.get_start_timestamp()
    
    def get_end_timestamp(self) -> int:
        """Retrieve the end timestamp.
        
        Returns:
            int: The end timestamp (ms).
        """
        
        return self._handler.get_end_timestamp()
    
    def get_topic_timestamps(self, topic: str) -> List[int]:
        """Retrieve message timestamps for a specific topic.
        
        Args:
            topic (str): The topic name.
        Raises:
            exceptions.TopicNotFoundError: Raised if the topic is not found.
        Returns:
            List[int]: A list of message timestamps for the specified topic.
        """
        if topic_info := self._handler._all_topics.get(topic):
            if topic_info["type"] != "had":
                times = list(self._handler.message_indexes.get(topic_info["channel_id"], []))
                times.sort()
                return times
        raise exceptions.ResourceNotFound(f"Topic {topic} not found!")
    
    def get_topic_message(
        self, 
        topic: str, 
        timestamp_ms: int
    ) -> Optional[Union[Message, ImageMessage, LidarMessage]]:
        """Retrieve a message for a specific topic at a given timestamp.
        
        Args:
            topic (str): The topic name.
            timestamp_ms (int): The message timestamp in milliseconds.
        Raises:
            exceptions.TopicNotFoundError: Raised if the topic is not found.
        Returns:
            Optional[Union[Message, ImageMessage, LidarMessage]]: The message for the specified topic and timestamp.
        """
        if topic_info := self._handler._all_topics.get(topic):
            if topic_info["type"] != "had":
                return self._handler.read_message_by_timestamp(topic, timestamp_ms)
        raise exceptions.ResourceNotFound(f"Topic {topic} not found!")
    
    def iter_raw_messages(
        self,
        start_timestamp_ms: int = None, 
        end_timestamp_ms: int = None, 
        topics: List[str] = None
    ) -> Iterator[Message]:
        """原始消息迭代器，仅迭代原始topic，类似cviz。

        Args:
            start_timestamp_ms (int, optional): The start timestamp in milliseconds.
            end_timestamp_ms (int, optional): The end timestamp in milliseconds.
            topics (List[str], optional): A list of topic names to filter messages.
        Raises:
            CloseError:  Raised if the reader is closed
        Yields:
            Iterator[Message]: An iterator over Message objects.
        """
        if self.closed:
            raise exceptions.ClosedError("Read of closed IO!")
        yield from self._handler.iter_raw_msgs_by_topics(start_timestamp_ms, end_timestamp_ms, topics)
    
    def __enter__(self):
        return self
    
    def __exit__(self, *args, **kwargs):
        if not self.closed:
            self.close()
    
    @property
    def closed(self) -> bool:
        return self._fp.closed
    
    def close(self):
        if not self.closed:
            self._fp.close()
