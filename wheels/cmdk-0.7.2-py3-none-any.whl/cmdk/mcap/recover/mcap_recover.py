import collections
from enum import IntEnum
import io
import logging
import os
import tempfile
from typing import Union, Optional
import shutil
import sys

from cmdk.mcap.writer.file_writer import MCAPWriter
from cmdk.utils.mcap_handler import OperationCode, MCAPReadMixin, BufferWriter, MCAPWriteMixin
from cmdk.utils.msg_decoder import FRAME_MSG_NAME, HAD_MSG_NAME
from cmdk.utils import tools

logger = logging.getLogger("cmdk")


class RecoveryStatus(IntEnum):
    SUCCESS = 0
    FILE_NOT_EXIST = 5
    EMPTY_FILE = 6
    IS_NOT_MCAP = 7
    SKIP_RECOVERY = 10

    @classmethod
    def _to_help(cls) -> str:
        items = []
        for name, _enum in cls.__members__.items():
            items.append(f"{_enum.value}:\t{name}")
        if sys.platform == "darwin":
            return "\n".join(items)
        return "\n\n".join(items)


class MCAPRecover(MCAPReadMixin, MCAPWriteMixin):
    def __init__(
            self, 
            mcap_path: Union[str, os.PathLike],
            output_path: Union[str, os.PathLike],
            recover_empty_file: bool = False,
        ):
        self.input_mcap = mcap_path
        self._fp = None
        self.mcap_size = None
        self.mcap_path = tools.BucketPath(mcap_path)
        self.output_path = tools.BucketPath(output_path)
        self.tmp_mcap = tempfile.mktemp(suffix=".mcap")
        self.tmp_fp = None
        if self.output_path.is_dir():
            self.output_path = tools.BucketPath(f"{self.output_path.local_path}/{mcap_path.name}")

        self.recover_empty_file = recover_empty_file

        self.footer = {}
        self.stream_summary = {
            "chunk_index": [],
            "channels": {},
            "schemas": {},
            "metadata_index": [],
            "attachment_index": [],
        }
        self._statistics = {
            "schema_count": 0,
            "channel_count": 0,
            "message_count": 0,
            "attachment_count": 0,
            "metadata_count": 0,
            "chunk_count": 0,
            "message_start_time": None,
            "message_end_time": None,
            "channel_message_counts": collections.defaultdict(int),
        }
        self._metadata = {}
        self._summary_offsets = []
        self._channel_seqs = {}

    def run(self) -> RecoveryStatus:
        self.log(f"开始检测mcap: {self.input_mcap}... ", level=logging.INFO, color=None)
        if status := self.check_is_mcap():
            return status
        
        if not self.check_valid_end():
            self.log("检测到文件不完整，开始解析恢复...", level=logging.INFO, color=None)
            return self._do_recover()
        else:
            self.log("文件完整，跳过恢复.", level=logging.INFO, color=None)
            self._fp.close()
            return RecoveryStatus.SKIP_RECOVERY
        
    def _do_recover(self):
        self._fp.seek(len(self.MAGIC), io.SEEK_SET)
        self.tmp_fp = open(self.tmp_mcap, "wb")
        self.tmp_fp.write(self.MAGIC)
        while True:
            try:
                opoffset = self._fp.tell()
                opcode = self.read_1_io(self._fp)
            except Exception:
                if self._fp.tell() >= self.mcap_size:
                    self._warn("遇到EOF.")
                break
            if opcode == OperationCode.CHUNK.value:
                self._recover_chunk_and_index()
            elif opcode == OperationCode.METADATA.value:
                metadata = self._read_metadata_from_io(self._fp)
                self._save_metadata(metadata["name"], metadata["metadata"])
                self._metadata.setdefault(metadata["name"], {}).update(metadata["metadata"])
            elif opcode == OperationCode.ATTACHMENT.value:
                attachment = self._read_attachment_from_io(self._fp)
                self.stream_summary["attachment_index"].append({
                    "name": attachment["name"],
                    "media_type": attachment["media_type"],
                    "log_time": attachment["log_time"],
                    "create_time": attachment["create_time"],
                    "data_size": len(attachment["data"]),
                    "length": attachment["_op_length"],
                    "offset": self.tmp_fp.tell(),
                })
                self._copy_records(opoffset)
            elif opcode == OperationCode.DATA_END.value:
                break
            elif opcode == OperationCode.HEADER.value:
                header = self._read_header_from_io(self._fp)
                self._save_header(header)
            elif opcode == OperationCode.MAGIC.value:
                break
            else:
                self._copy_records(opoffset)
        self._end_recover()
        self._fp.close()
        self.tmp_fp.close()
        shutil.move(self.tmp_mcap, self.output_path.local_path)
        self.log(f"恢复完成, 输出文件: {self.output_path}", level=logging.INFO, color="green")
        return RecoveryStatus.SUCCESS

    def _recover_chunk_and_index(self):
        try:
            chunk = self._read_chunk_from_io(self._fp)
            if chunk["compressed_size"] != len(chunk["data"]):
                self._err(f"Chunk数据不完整, 停止恢复.")
                return False
        except Exception as e:
            self._err(f"Chunk无法解析, 停止恢复.")
            return False
        
        channels, schemas, msgs = self._read_records_from_chunk(chunk)

        self._save_chunk(chunk)
        
        for schema in schemas:
            self.stream_summary["schemas"][schema["id"]] = schema

        for channel in channels:        
            self.stream_summary["channels"][channel["id"]] = channel
        
        self._statistics["chunk_count"] += 1
        self._statistics["message_count"] += len(msgs)
        if self._statistics["message_start_time"] is None:
            self._statistics["message_start_time"] = chunk["message_start_time"]
            self._statistics["message_end_time"] = chunk["message_end_time"]
        else:
            self._statistics["message_start_time"] = min(self._statistics["message_start_time"], chunk["message_start_time"])
            self._statistics["message_end_time"] = max(self._statistics["message_end_time"], chunk["message_end_time"])

        stream_msg_index = {}
        for msg in msgs:
            channel_id = msg["channel_id"]
            stream_msg_index.setdefault(channel_id, []).append({
                "timestamp": msg["log_time"],
                "offset": msg["_coffset"],
            })
            self._statistics["channel_message_counts"][channel_id] += 1
        source_msg_index = {}
        first_chunk_index_offset = self.tmp_fp.tell()
        while True:
            try:
                op_offset = self._fp.tell()
                opcode = self.read_1_io(self._fp)
            except Exception:
                break
            if opcode == OperationCode.MESSAGE_INDEX.value:
                try:
                    msg_index = self._read_message_index_from_io(self._fp)
                    chunk["message_index_offsets"][msg_index["channel_id"]] = self.tmp_fp.tell()
                    self._save_msg_index(msg_index)
                    source_msg_index[msg_index["channel_id"]] = msg_index
                except Exception as e:
                    self._err(f"Message Index {op_offset:#X} 无法解析.")
                    break
            else:
                self._fp.seek(-1, io.SEEK_CUR)
                break
        for channel_id, records in stream_msg_index.items():
            if channel_id not in source_msg_index:
                chunk["message_index_offsets"][channel_id] = self.tmp_fp.tell()
                self._save_msg_index({"channel_id": channel_id, "records": records})
        chunk["message_index_length"] = self.tmp_fp.tell() - first_chunk_index_offset
        return True
    
    def _end_recover(self):
        frame_msg_map = self._metadata.get("frame_msg_map", {})
        for name, value in self._build_frame_msg_map().items():
            if name not in frame_msg_map:
                frame_msg_map[name] = value
        self._metadata.setdefault("frame_msg_map", {}).update(frame_msg_map)
        for name, metadata in self._metadata.items():
            self._save_metadata(name, metadata)
        
        self._save_data_end()
        
        summary_offsets = []
        summary_start = self.tmp_fp.tell()
        group_start = summary_start
        if self.stream_summary["schemas"]:
            for schema in self.stream_summary["schemas"].values():
                self._save_schema(schema)
            summary_offsets.append({
                "group_opcode": OperationCode.SCHEMA.value,
                "group_start": group_start,
                "group_length": self.tmp_fp.tell() - group_start,
            })
        group_start = self.tmp_fp.tell()
        if self.stream_summary["channels"]:
            for channel in self.stream_summary["channels"].values():
                self._save_channel(channel)
            summary_offsets.append({
                "group_opcode": OperationCode.CHANNEL.value,
                "group_start": group_start,
                "group_length": self.tmp_fp.tell() - group_start,
            })
        group_start = self.tmp_fp.tell()
        if self.stream_summary["chunk_index"]:
            for chunk in self.stream_summary["chunk_index"]:
                self._save_chunk_index(chunk)
            summary_offsets.append({
                "group_opcode": OperationCode.CHUNK_INDEX.value,
                "group_start": group_start,
                "group_length": self.tmp_fp.tell() - group_start,
            })
        group_start = self.tmp_fp.tell()
        if self.stream_summary["metadata_index"]:
            for metadata_index in self.stream_summary["metadata_index"]:
                self._save_metadata_index(metadata_index)
            summary_offsets.append({
                "group_opcode": OperationCode.METADATA_INDEX.value,
                "group_start": group_start,
                "group_length": self.tmp_fp.tell() - group_start,
            })
        group_start = self.tmp_fp.tell()
        if self.stream_summary["attachment_index"]:
            for attachment_index in self.stream_summary["attachment_index"]:
                self._save_attachment_index(attachment_index)
            summary_offsets.append({
                "group_opcode": OperationCode.ATTACHMENT_INDEX.value,
                "group_start": group_start,
                "group_length": self.tmp_fp.tell() - group_start,
            })
        group_start = self.tmp_fp.tell()
        self._statistics["schema_count"] = len(self.stream_summary["schemas"])
        self._statistics["channel_count"] = len(self.stream_summary["channels"])
        self._statistics["metadata_count"] = len(self.stream_summary["metadata_index"])
        self._statistics["attachment_count"] = len(self.stream_summary["attachment_index"])
        self._save_statistics()
        summary_offsets.append({
            "group_opcode": OperationCode.STATISTICS.value,
            "group_start": group_start,
            "group_length": self.tmp_fp.tell() - group_start,
        })
        summary_offset_start = self.tmp_fp.tell()
        for summary_offset in summary_offsets:
            self._save_summary_offset(summary_offset)
        self._save_footer({"summary_start": summary_start, "summary_offset_start": summary_offset_start, "summary_crc": 0})
    
    def _build_frame_msg_map(self):
        frame_msg_map = {}
        frames = {}
        for ch_info in self.stream_summary["channels"].values():
            topic = ch_info["topic"]
            schema_info = self.stream_summary["schemas"][ch_info["schema_id"]]
            if schema_info["name"] == HAD_MSG_NAME:
                continue
            elif schema_info["name"] == FRAME_MSG_NAME:
                if topic.endswith("/frame"):
                    _frame = topic[:-6]
                    frames[_frame] = topic
                    frame_msg_map.setdefault(_frame, set())
                else:
                    frames[topic] = topic
                    frame_msg_map.setdefault(topic, set())
            else:
                segs = topic.split("-", 1)
                if len(segs) == 2:
                    frame_msg_map.setdefault(segs[1], set())
                    frame_msg_map[segs[1]].add(topic)
        result = {}
        for frame_topic, topics in frame_msg_map.items():
            if frame_topic in frames:
                result[frames[frame_topic]] = "###".join(topics)
        return result
    
    def _save_header(self, info):
        this_lib = "CMDK"
        library = info["library"]
        if this_lib not in library:
            library += f"; {self.LIBRARY}"
        else:
            tmp = [
                seg.strip()
                for i, seg in enumerate(library.split(";"))
                if this_lib not in seg or i == 0
            ]
            library = "; ".join(tmp)
            if this_lib not in library:
                library += f"; {self.LIBRARY}"
        buffer = BufferWriter()
        self._write_header("", library, buffer)
        self.tmp_fp.write(buffer.dump())

    def _save_schema(self, info):
        buffer = BufferWriter()
        self._write_schema(info, buffer)
        self.tmp_fp.write(buffer.dump())

    def _save_channel(self, info):
        buffer = BufferWriter()
        self._write_channel(info, buffer)
        self.tmp_fp.write(buffer.dump())
    
    def _save_chunk(self, info):
        buffer = BufferWriter()
        self._write_chunk(info, buffer)
        chunk_start_offset = self.tmp_fp.tell()
        self.tmp_fp.write(buffer.dump())
        info.update({
            "chunk_start_offset": chunk_start_offset,
            "chunk_length": self.tmp_fp.tell() - chunk_start_offset,
            "message_index_offsets": {},
            "message_index_length": 0,
        })
        self.stream_summary["chunk_index"].append(info)
        return info

    def _save_msg_index(self, info):
        buffer = BufferWriter()
        self._write_message_index(info, buffer)
        self.tmp_fp.write(buffer.dump())
    
    def _save_metadata(self, name, metadata):
        buffer = BufferWriter()
        self._write_metadata(name, metadata, buffer)
        offset = self.tmp_fp.tell()
        self.tmp_fp.write(buffer.dump())
        length = self.tmp_fp.tell() - offset
        self.stream_summary["metadata_index"].append({
            "name": name,
            "length":length,
            "offset": offset,
        })

    def _save_data_end(self):
        buffer = BufferWriter()
        self._write_data_end(buffer)
        self.tmp_fp.write(buffer.dump())

    def _save_chunk_index(self, info):
        buffer = BufferWriter()
        self._write_chunk_index(info, buffer)
        self.tmp_fp.write(buffer.dump())
    
    def _save_metadata_index(self, info):
        buffer = BufferWriter()
        self._write_metadata_index(info, buffer)
        self.tmp_fp.write(buffer.dump())
    
    def _save_attachment_index(self, info):
        buffer = BufferWriter()
        self._write_attachment_index(info, buffer)
        self.tmp_fp.write(buffer.dump())
    
    def _save_statistics(self):
        buffer = BufferWriter()
        self._write_statistics(self._statistics, buffer)
        self.tmp_fp.write(buffer.dump())

    def _save_summary_offset(self, info):
        buffer = BufferWriter()
        self._write_summary_offset(info, buffer)
        self.tmp_fp.write(buffer.dump())
    
    def _save_footer(self, info):
        buffer = BufferWriter()
        self._write_footer(info, buffer)
        self.tmp_fp.write(buffer.dump())

    def _copy_records(self, opoffset) -> int:
        self._fp.seek(opoffset, io.SEEK_SET)
        data = self._fp.read(9)
        length, _ = self.read_8(data, 1)
        self.tmp_fp.write(data)
        self.tmp_fp.write(self._fp.read(length))
        return length + 1
    
    def check_valid_end(self):
        self._fp.seek(-37, io.SEEK_END)
        data = self._fp.read()
        footer_data = data[:29]
        magic = data[29:]
        if footer_data[0] != 0x02:
            self._err("文件缺少Footer")
            return False
        try:
            footer_data, _ = self._read_footer_from_data(footer_data, 1)
            self.footer.update(footer_data)
        except Exception as e:
            self._err(f"文件Footer无法解析: {e}.")
            return False
        if self.footer["summary_start"] == 0:
            self._err("文件结尾缺少Summary记录.")
            return False
        if magic != self.MAGIC:
            self._err("文件结尾缺少MCAP标记, 该MCAP文件写过程可能出现中断.")
            return False
        return True
    
    def _recover_empty_file(self):
        if self.recover_empty_file:
            logger.info(f"Recovering empty MCAP file: {self.mcap_path}")
            with MCAPWriter(self.output_path):
                pass
            return RecoveryStatus.SUCCESS
        return RecoveryStatus.IS_NOT_MCAP

    def check_is_mcap(self) -> Optional[RecoveryStatus]:
        if not os.path.exists(self.input_mcap):
            self._err(f"{self.input_mcap} 文件不存在.")
            return RecoveryStatus.FILE_NOT_EXIST

        if os.path.isdir(self.input_mcap):
            self._err(f"{self.input_mcap} 是一个目录，不是文件.")
            return RecoveryStatus.IS_NOT_MCAP
        
        self.mcap_size = os.path.getsize(self.input_mcap)
        if self.mcap_size == 0:
            return self._recover_empty_file()
        
        self._fp = open(self.input_mcap, 'rb')
        if self._fp.read(len(self.MAGIC)) != self.MAGIC:
            return RecoveryStatus.IS_NOT_MCAP

    def __enter__(self):
        return self
    
    def __exit__(self, *args, **kwargs):
        if not self.closed:
            self.close()
    
    @property
    def closed(self) -> bool:
        return self._fp.closed
    
    def close(self):
        if not self.closed:
            self._fp.close()

    def log(self, string, level=logging.ERROR, color="red"):
        if os.environ.get("_CMDK_RICH_LOGGING") == "1" and color:
            logger.log(level, f"[{color} bold]{string}", extra={"markup": True})
        else:
            logger.log(level, string)
    
    def _err(self, string):
        self.log(string, level=logging.ERROR, color="red")

    def _warn(self, string):
        self.log(string, level=logging.WARNING, color="yellow")