import datetime
import os
import socket
import time
from typing import Dict, List
import uuid

import requests
import msgpack
import orjson

from cmdk import __version__
from cmdk.common import settings, exceptions
from cmdk.utils import tools
from cmdk.utils.msg_decoder import (
    IMAGE_MSG_NAMES,
    LIDAR_MSG_NAMES
)


class MSSServer:
    def __init__(self, env):
        self.env = env
        self.endpoint = settings.MSS_SERVER_ENDPOINT[env]
        self.session = requests.Session()
        self.session.headers.update({
            "User-Agent": f"cmdk-python/{__version__}",
            "Real-IP": tools.get_local_ip()
        })
        self._is_dns_ok = False

    def get_topic_info_v2(self, vehicle_id: str, start_ts: int, end_ts: int, topics: list = None):
        return self.request(
            method="POST",
            path="/api/v2/mcap/topics-index-locations",
            json={
                "vehicle_id": vehicle_id,
                "start_ts": start_ts,
                "end_ts": end_ts,
                "topics": topics or []
            }
        )
    
    def search_clips(self, vehicle_id: str, start_ts: int, end_ts: int, topics: list = None) -> List[dict]:
        if not vehicle_id:
            raise exceptions.MSSServerException(
                msg="vehicle_id is empty!",
                code=400
            )
        
        if start_ts > end_ts:
            raise exceptions.MSSServerException(
                msg=f"start_ts {start_ts} is greater than end_ts {end_ts}!",
                code=400
            )
        
        topics = topics or []
        if topics and not isinstance(topics[0], str):
            raise exceptions.MSSServerException(
                msg="topics must be a list of strings!",
                code=400
            )
        
        return self.request(
            method="POST",
            path="/api/v2/mcap/search-clips",
            json={
                "vehicle_id": vehicle_id,
                "start_ts": start_ts,
                "end_ts": end_ts,
                "topics": topics
            }
        )

    def get_chunk_index(self, vehicle_id: str, start_ts: int, end_ts: int, topics: list = None) -> Dict[str, dict]:
        return self.request(
            method="POST",
            path="/api/v1/mcap/topics-chunks",
            json={
                "vehicle_id": vehicle_id,
                "start_ts": start_ts,
                "end_ts": end_ts,
                "topics": topics or []
            }
        )

    @tools.retry(retries=3)
    def get_index_info(self, index_path: str):
        bucket_file = f"/horizon-bucket/{index_path}"        
        with open(bucket_file, "rb") as fp:
            data = fp.read()
        return msgpack.unpackb(data, strict_map_key=False)

    def get_index_info_with_cache(self, index_path: str):
        cache_file = settings.INDEX_CACHE_DIR / index_path
        if cache_file.exists():
            with cache_file.open("rb") as fp:
                data = fp.read()
        else:
            data = self.request(
                method="GET",
                path="/api/v1/mcap/download-file",
                params={
                    "jfs_path": index_path
                }
            )
            cache_file.parent.mkdir(parents=True, exist_ok=True)
            with cache_file.open("wb") as fp:
                fp.write(data)
        return msgpack.unpackb(data, strict_map_key=False)

    def get_index_info_with_bucket(self, index_path: str):
        bucket_file = f"/horizon-bucket/{index_path}"
        if os.path.exists(bucket_file):
            with open(bucket_file, "rb") as fp:
                data = fp.read()
        else:
            data = self.request(
                method="GET",
                path="/api/v1/mcap/download-file",
                params={
                    "jfs_path": index_path
                }
            )
        return msgpack.unpackb(data, strict_map_key=False)

    def get_clip_index_info_v2(self, vehicle_id: str, start_ts: int, end_ts: int, topics: list = None):
        clips_info = self.get_topic_info_v2(vehicle_id, start_ts, end_ts, topics)
        info = {
            "vehicle_id": vehicle_id,
            "start_ts": start_ts,
            "end_ts": end_ts,
        }
        if topics:
            topics = set(topics)
        topics_info = {}
        for clip_info in clips_info:
            topic_mcap_info = dict()
            mcap_index_info = {}
            for topic, mcap_name in clip_info["topic_mcaps"].items():
                if topics and topic in topics:
                    topic_mcap_info[topic] = mcap_name
                    mcap_index_info[mcap_name] = None
            
            for mcap_name in list(mcap_index_info.keys()):
                chunk_idx = self.get_index_info_with_bucket(clip_info["index_dir"] + "/" + mcap_name.replace('.mcap', '.chidx'))
                frame_idx = self.get_index_info_with_bucket(clip_info["index_dir"] + "/" + mcap_name.replace('.mcap', '.fridx'))
                mcap_index_info[mcap_name] = (chunk_idx, frame_idx)

            for topic, mcap_name in list(topic_mcap_info.items()):
                mcap_path = f'{clip_info["mcap_dir"]}/{mcap_name}'
                chunk_idx, frame_idx = mcap_index_info[mcap_name]

                topics_info.setdefault(topic, {}).setdefault("schema", chunk_idx["schemas"][topic])
                if idr_frame := frame_idx[topic].get("idr_frame"):
                    idr_info = {
                        "mcap_file": mcap_path,
                        "frame": idr_frame,
                        "chunk": self._chunk_to_dict(chunk_idx["chunks"][idr_frame[3]])
                    }
                    topics_info[topic].setdefault("idr_frame", idr_info)
                if lidar_info := frame_idx[topic].get("lidar_info"):
                    if "lidar_info" in topics_info[topic]:    
                        topics_info[topic]["lidar_info"]["max_point_count"] = max(
                            topics_info[topic]["lidar_info"]["max_point_count"], lidar_info["max_point_count"])
                    else:
                        topics_info[topic]["lidar_info"] = lidar_info

                frames = []
                for _frame in frame_idx[topic]["frames"]:
                    if start_ts <= _frame[0] <= end_ts:
                        frames.append(_frame)
                chunks = [
                    self._chunk_to_dict(c)
                    for c in chunk_idx["chunks"]
                ]

                topics_info[topic].setdefault("mcaps", []).append({
                    "mcap_file": mcap_path,
                    "frames": frames,
                    "chunks": chunks
                })
        info["topics"] = topics_info
        return info

    def get_clip_info(self, vehicle_id: str, start_ts: int, end_ts: int, topics: list):
        if not topics:
            return {}
        clips_info = self.search_clips(vehicle_id, start_ts, end_ts, topics)
        info = {
            "vehicle_id": vehicle_id,
            "start_ts": start_ts,
            "end_ts": end_ts,
        }
        topics_info = {}
        topics = set(topics)
        for clip_info in clips_info:
            mcaps_info = clip_info.get("mcap_info") or {}
            topic_mcaps = dict()
            topic_types = dict()
            mcap_topics = dict()
            for mcap_name, _mcap_info in mcaps_info.items():
                if _mcap_info["st"] > end_ts or _mcap_info["et"] < start_ts:
                    continue
                
                filter_topics = topics.intersection(_mcap_info["topics"])
                if not filter_topics:
                    continue
                
                for _topic in filter_topics:
                    if _topic not in topic_mcaps:
                        topic_mcaps[_topic] = mcap_name
                        mcap_topics.setdefault(mcap_name, []).append(_topic)
                topic_types.update(self.get_topic_type(_mcap_info["msg_map"]))
            
            for mcap_name, _topics in mcap_topics.items():                
                mcap_path = clip_info["clip_dir"] + "/" + mcap_name
                chunk_idx = self.get_index_info(clip_info["index_dir"] + "/" + mcap_name[:-5] + ".chidx")
                frame_idx = self.get_index_info(clip_info["index_dir"] + "/" + mcap_name[:-5] + ".fridx")
                
                for topic in _topics:
                    topics_info.setdefault(topic, {}).setdefault("schema", chunk_idx["schemas"][topic])
                    topics_info[topic].setdefault("topic_type", topic_types[topic])
                    
                    if idr_frame := frame_idx[topic].get("idr_frame"):
                        idr_info = {
                            "mcap_file": mcap_path,
                            "frame": idr_frame,
                            "chunk": self._chunk_to_dict(chunk_idx["chunks"][idr_frame[3]])
                        }
                        topics_info[topic].setdefault("idr_frame", idr_info)
                    
                    if lidar_info := frame_idx[topic].get("lidar_info"):
                        if "lidar_info" in topics_info[topic]:    
                            topics_info[topic]["lidar_info"]["max_point_count"] = max(
                                topics_info[topic]["lidar_info"]["max_point_count"], lidar_info["max_point_count"])
                        else:
                            topics_info[topic]["lidar_info"] = lidar_info

                    frames = []
                    for _frame in frame_idx[topic]["frames"]:
                        if start_ts <= _frame[0] <= end_ts:
                            frames.append(_frame)
                    chunks = [
                        self._chunk_to_dict(c)
                        for c in chunk_idx["chunks"]
                    ]
                    
                    topics_info[topic].setdefault("mcaps", []).append({
                        "mcap_file": mcap_path,
                        "frames": frames,
                        "chunks": chunks
                    })
        info["topics"] = topics_info
        return info   

    def upload_ex_index(self, data, username=None, description=None):
        files = {
            "file": ("extract_index.exidx", msgpack.packb(data), "application/octet-stream")
        }
        payload = {
            "vehicle_id": data["vehicle_id"],
            "topic_list": list(data["topics"].keys()),
            "username": username or settings.USERNAME,
        }
        if description:
            payload["description"] = description
        response = self.request(
            method="POST",
            path="/api/v1/mcap/ex_index/upload",
            data=payload,
            files=files
        )
        return response["index_id"]

    def upload_ex_index_v2(self, data, username=None, description=None):
        vehicle_id = data["vehicle_id"]
        topic_list = list(data["topics"].keys())
        now = datetime.datetime.now()
        
        unique_id = uuid.uuid4().hex[:8]  # 生成短 UUID
        timestamp = now.strftime("%Y%m%d%H%M%S")
        
        jfs_path = f"/horizon-bucket/carizon_collect_jfs/mcap_index/extract_frame_index/{vehicle_id}/{now.year}_{now.month}_{now.day}/{timestamp}_{unique_id}.exidx"
        os.makedirs(os.path.dirname(jfs_path), exist_ok=True)
        with open(jfs_path, "wb") as fp:
            fp.write(msgpack.packb(data))

        payload = {
            "file": jfs_path,
            "vehicle_id": data["vehicle_id"],
            "topic_list": topic_list,
            "username": username or settings.USERNAME,
        }
        if description:
            payload["description"] = description
        response = self.request(
            method="POST",
            path="/api/v1/mcap/ex_index/meta",
            data=payload,
        )
        return response["index_id"]

    def get_ex_index(self, index_id: str) -> Dict[str, dict]:
        data = self.request(
            method="GET",
            path=f"/api/v1/mcap/ex_index/{index_id}",
        )
        return msgpack.unpackb(data, strict_map_key=False)

    def get_ex_index_v2(self, index_id: str) -> Dict[str, dict]:
        file_path = self.request(
            method="GET",
            path=f"/api/v1/mcap/ex_index/{index_id}/jfs_path",
        )["file_path"]
        if os.path.exists(file_path):
            with open(file_path, "rb") as fp:
                return msgpack.unpackb(fp.read(), strict_map_key=False)
        else:
            return self.get_ex_index(index_id)

    def request(self, method, path, params=None, json=None, data=None, files=None, reties=3):
        self._fix_dns()

        url = self.endpoint + path
        retry = 0
        resp = None
        
        while True:
            try:
                resp = self.session.request(
                    method=method, url=url, params=params, json=json, data=data, files=files, timeout=60)

                if resp.status_code != 200:
                    raise exceptions.MSSServerException(
                        msg=f"request {url} http status error",
                        code=resp.status_code,
                        extra={
                            "params": params,
                            "data": data,
                            "response": resp.content
                        }
                    )
                if not resp.content:
                    raise Exception("No content")

                if resp.headers["content-type"] == "application/json":
                    resp_data = orjson.loads(resp.content)
                elif resp.headers["content-type"] == "application/msgpack":
                    resp_data = msgpack.unpackb(resp.content, strict_map_key=False)
                elif resp.headers["content-type"] == "application/octet-stream":
                    return resp.content
                else:
                    raise exceptions.MSSServerException(
                        msg=f"unsupported content-type: {resp.headers['content-type']}", code=900)

                if resp_data["status"] == 0:
                    return resp_data["data"]

                raise exceptions.MSSServerException(
                    msg=f"request {url} response status error",
                    code=resp_data["status"],
                    extra={
                        "params": params,
                        "data": data,
                        "response": resp_data
                    }
                )
            except Exception as e:
                retry += 1
                if retry >= reties:
                    if isinstance(e, exceptions.MSSServerException):
                        raise
                    raise exceptions.MSSServerException(
                        msg=str(e),
                        code=getattr(resp, "code", 500),
                        extra={
                            "params": params,
                            "data": data,
                            "response": None,
                        }
                    )
                time.sleep(0.5)

    @staticmethod
    def get_topic_type(topic_msg_map: dict) -> dict:
        result = {}
        for topic, msg_name in topic_msg_map.items():
            if msg_name in IMAGE_MSG_NAMES:
                result[topic] = "image"
                if f"{topic}/data" in topic_msg_map:
                    result[f"{topic}/data"] = "image/data"
            elif msg_name in LIDAR_MSG_NAMES:
                result[topic] = "lidar"
                if f"{topic}/data" in topic_msg_map:
                    result[f"{topic}/data"] = "lidar/data"
            else:
                if topic not in result:
                    result[topic] = "proto"
        return result
    
    @staticmethod
    def _chunk_to_dict(chunk):
        return {
            "start_ts": chunk[0],
            "end_ts": chunk[1],
            "offset": chunk[2],
            "size": chunk[3],
            "compression": chunk[4],
            "uncompressed_size": chunk[5]
        }
    
    def get_obstruct_core(self):
        content = self.request(
            method="GET",
            path=f"/api/v1/mcap/mcap_obstruct_latest",
        )
        return content

    def _is_connectable(self):
        try:
            resp = self.session.get(f"{settings.MSS_SERVER_ENDPOINT['prod']}/health", timeout=0.1)
            return resp.headers.get("content-type", "").startswith(("application/json", "text/plain"), )
        except Exception:
            return False

    def _fix_dns(self):
        if self._is_dns_ok:
            return
        self._is_dns_ok = True
        if self._is_connectable():
            return True
        try:
            gaia_ip = None
            addrs = socket.getaddrinfo("data.gaia.carizon.work", 443)
            for addr in addrs:
                gaia_ip = addr[4][0]
                break
            
            _, network = tools.identify_network()
            curr_network = None
            if gaia_ip == settings.settings.OFFICE_DNS["data.gaia.carizon.work"]:
                curr_network = "OFFICE"
            elif gaia_ip == settings.settings.CLOUD_DNS["data.gaia.carizon.work"]:
                curr_network = "CLOUD"
            if curr_network != network:
                tools.do_pached_dns(network)
        except Exception:
            tools.do_pached_dns()
        

mss_server_cli = MSSServer(env=os.environ.get("MSS_SERVER_ENV", "prod"))
