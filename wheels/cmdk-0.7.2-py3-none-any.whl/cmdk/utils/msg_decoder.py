import lz4.block
import re
import sys
import threading
import io

import av
import cv2
from google.protobuf.descriptor_pb2 import FileDescriptorSet
from google.protobuf.descriptor_pool import DescriptorPool
from google.protobuf.json_format import MessageToDict
try:
    from google.protobuf.message_factory import GetMessageClass
except ImportError:
    from google.protobuf.message_factory import MessageFactory
    GetMessageClass = MessageFactory().GetPrototype
from mcap_ros2._dynamic import generate_dynamic
from numpy.typing import NDArray
import numpy as np
import orjson
from turbojpeg import TurboJPEG, TJSAMP_420, TJFLAG_FASTDCT

from cmdk.common import exceptions, settings, enums


class CameraCodec:
    def __init__(self):
        self._dc = av.codec.CodecContext.create("hevc", "r")
        self._turbojpeg = self._get_turbo_jpeg_obj()
        self._threads_dc = {threading.get_ident(): self._dc}

    def set_extra(self, data):
        self._dc.extradata = data

    def set_extras(self, data_list):
        self._dc.extradata = data_list[0][data_list[1]]

    def to_ndarray(self, frame_data, format="bgr24") -> NDArray:
        return self._to_frame(frame_data).to_ndarray(format=format)

    def to_jpg(self, frame_data, quality: int = 95) -> bytes:
        frame = self._to_frame(frame_data)
        return self._turbojpeg.encode_from_yuv(
            frame.to_ndarray(format="yuvj420p"), 
            frame.height, 
            frame.width, 
            jpeg_subsample=TJSAMP_420,
            quality=quality,       
            flags=TJFLAG_FASTDCT
        )

    def _to_frame(self, frame_data) -> av.VideoFrame:
        _dc = self._threads_dc.get(threading.get_ident())
        if not _dc:
            _dc = av.codec.CodecContext.create("hevc", "r")
            _dc.extradata = self._dc.extradata
            self._threads_dc[threading.get_ident()] = _dc
        try:
            frames = _dc.decode(av.Packet(frame_data))
        except Exception:
            _dc.flush_buffers()
            frames = _dc.decode(av.Packet(frame_data))
        if not frames:
            frames = _dc.decode()
            if not frames:
                raise exceptions.InvalidMessageError(f"Failed to decode camera data: {frame_data}")
        frame = frames[0]
        return frame

    @staticmethod
    def array_to_jpg(array, quality: int = 95, resize_scale=100, resize_width=None):
        if resize_width:
            height, width = array.shape[:2]
            height = int(resize_width / width * height)
            array = cv2.resize(array, (resize_width, height), interpolation=cv2.INTER_AREA)
        elif resize_scale != 100:
            height, width = array.shape[:2]
            height = int(height * resize_scale / 100)
            width = int(width * resize_scale / 100)
            array = cv2.resize(array, (width, height), interpolation=cv2.INTER_AREA)
        _, buf = cv2.imencode(".jpg", array,[cv2.IMWRITE_JPEG_QUALITY, quality])
        return buf.tobytes()
    
    @staticmethod
    def _get_turbo_jpeg_obj():
        if sys.platform.startswith("linux"):
            return TurboJPEG(settings.CMDK_BASE_DIR / "lib/libturbojpeg.so.0.4.0")
        elif sys.platform.startswith("win"):
            return TurboJPEG(settings.CMDK_BASE_DIR / "lib/libturbojpeg.dll")
        return TurboJPEG(settings.CMDK_BASE_DIR / "lib/libturbojpeg.0.4.0.dylib")
    
    @staticmethod
    def from_array(img_array, format="rgb24") -> bytes:
        frame = av.VideoFrame.from_ndarray(img_array, format=format)
        codec = av.CodecContext.create("hevc", "w")
        codec.width = frame.width
        codec.height = frame.height
        codec.pix_fmt = "yuv420p"
        packets = codec.encode(frame)
        if not packets:
            packets = codec.encode()
        return b''.join([bytes(pkt) for pkt in packets])


class CameraProtoCodec(CameraCodec):
    def __init__(self, pb_codec: "ProtobufCodec"):
        self.pb_codec = pb_codec
        super().__init__()
    
    def decode(self, data, format="jpg", **kwargs) -> bytes:
        return self.to_jpg(self.pb_codec(data).data_blocks[0].data)


XYZIRT_PCD_HEADER = """VERSION 0.7
FIELDS x y z intensity ring time
SIZE 4 4 4 1 2 4
TYPE F F F U U U
COUNT 1 1 1 1 1 1
WIDTH {0}
HEIGHT 1
VIEWPOINT 0.0 0.0 0.0 1.0 0.0 0.0 0.0
POINTS {0}
DATA {1}
"""


class LidarDecoder:
    def __init__(self, pb_codec: "ProtobufCodec", max_points=None, pcd_type=None, scale=100):
        self.pb_codec = pb_codec
        self.max_points = max_points
        self.pcd_type = pcd_type
        self.scale = scale
    
    def decode(self, data, points=None):
        points = points or self.max_points
        return self.decode_data(
            self.pb_codec(data).data_blocks[0].data, points, pcd_type=self.pcd_type, scale=self.scale)
    
    @classmethod
    def decode_data(cls, data, points, pcd_type, scale=100):
        if pcd_type == enums.LidarDataType.INT16_COMPRESSED.value:
            return cls.decode_data_int16(data, points, scale=scale)
        elif pcd_type == enums.LidarDataType.FLOAT32_COMPRESSED.value:
            return cls.decode_data_float32(data, points)
        else:
            raise exceptions.UnsupportedError(f"Unsupported pcd type {pcd_type}!")
        
    @staticmethod
    def decode_data_int16(data, points, scale=100):
        decompressed_data = lz4.block.decompress(data, points * 13)
        points = len(decompressed_data) // 13
        x = np.frombuffer(decompressed_data, dtype=np.int16, count=points, offset=0)
        y = np.frombuffer(decompressed_data, dtype=np.int16, count=points, offset=2 * points)
        z = np.frombuffer(decompressed_data, dtype=np.int16, count=points, offset=4 * points)
        intensity = np.frombuffer(decompressed_data, dtype=np.uint8, count=points, offset=6 * points)
        ring = np.frombuffer(decompressed_data, dtype=np.uint16, count=points, offset=7 * points)
        timestamp = np.frombuffer(decompressed_data, dtype=np.uint32, count=points, offset=9 * points)
        pts = np.empty((points, 6), dtype=np.float32)
        pts[:, 0] = x.astype(np.float32) / scale
        pts[:, 1] = y.astype(np.float32) / scale
        pts[:, 2] = z.astype(np.float32) / scale
        pts[:, 3] = intensity.astype(np.float32)
        pts[:, 4] = ring.astype(np.float32)
        pts[:, 5] = timestamp.astype(np.float32)
        return pts

    @staticmethod
    def decode_data_float32(data, points):
        decompressed_data = lz4.block.decompress(data, points * 19)
        points = len(decompressed_data) // 19
        x = np.frombuffer(decompressed_data, dtype=np.float32, count=points, offset=0)
        y = np.frombuffer(decompressed_data, dtype=np.float32, count=points, offset=4 * points)
        z = np.frombuffer(decompressed_data, dtype=np.float32, count=points, offset=8 * points)
        intensity = np.frombuffer(decompressed_data, dtype=np.uint8, count=points, offset=12 * points)
        ring = np.frombuffer(decompressed_data, dtype=np.uint16, count=points, offset=13 * points)
        timestamp = np.frombuffer(decompressed_data, dtype=np.uint32, count=points, offset=15 * points)
        pts = np.empty((points, 6), dtype=np.float32)
        pts[:, 0] = x
        pts[:, 1] = y
        pts[:, 2] = z
        pts[:, 3] = intensity.astype(np.float32)
        pts[:, 4] = ring.astype(np.float32)
        pts[:, 5] = timestamp.astype(np.float32)
        return pts

    @staticmethod
    def to_pcd(points: np.ndarray, encoding: str = "binary") -> bytes:
        if encoding not in ("binary", "ascii"):
            raise exceptions.InvalidParamError(f"Unsupported PCD encoding type: {encoding}")
        
        header = XYZIRT_PCD_HEADER.format(points.shape[0], encoding).encode()
        
        if encoding == "binary":
            dt = np.dtype([
                ("x", np.float32),
                ("y", np.float32),
                ("z", np.float32),
                ("intensity", np.uint8),
                ("ring", np.uint16),
                ("time", np.uint32)
            ])
            data = np.rec.fromarrays(points.T, dtype=dt).tobytes()
        else:
            with io.BytesIO() as bio:
                np.savetxt(bio, points, fmt="%.10f %.10f %.10f %d %d %d")
                data = bio.getvalue()
        return header + data


class ProtobufCodec:
    def __init__(self, pb_class):
        self.pb_class = pb_class
    
    def decode(self, data):
        pb = self.pb_class()
        pb.ParseFromString(data)
        return MessageToDict(pb, preserving_proto_field_name=True)

    def __call__(self, data):
        pb = self.pb_class()
        pb.ParseFromString(data)
        return pb

    @classmethod
    def from_schema(cls, schema):
        fds_map = {_fds.name: _fds for _fds in FileDescriptorSet.FromString(schema["data"]).file}
        _dp = DescriptorPool()
        def _parse(_fds):
            for dep in _fds.dependency:
                if dep in fds_map:
                    _parse(fds_map.pop(dep))
            _dp.Add(_fds)
        while fds_map:
            _parse(fds_map.popitem()[1])
        return cls(GetMessageClass(_dp.FindMessageTypeByName(schema["name"])))

    @staticmethod
    def export_schema(pb) -> bytes:
        stack = [pb.DESCRIPTOR.file]
        names = set()
        file_descriptors = []
        while stack:
            fd = stack.pop()
            if fd.name in names:
                continue
            names.add(fd.name)
            stack.extend(fd.dependencies)
            file_descriptors.append(fd)

        fd_set = FileDescriptorSet()
        for fd in file_descriptors[::-1]:
            fd_set.file.add().ParseFromString(fd.serialized_pb)
        return fd_set.SerializeToString()

    @staticmethod
    def encode(pb) -> bytes:
        try:
            return pb.SerializeToString()
        except Exception as e:
            raise exceptions.InvalidParamError(f"Failed to encode protobuf message {pb} to bytes: {e}") from None


class JsonCodec:
    def __call__(self, data: bytes):
        return orjson.loads(data)

    @staticmethod
    def encode(obj: dict) -> bytes:
        try:
            return orjson.dumps(obj)
        except Exception as e:
            raise exceptions.InvalidParamError(f"Failed to encode object {obj} to json: {e}") from None


class Ros2Codec:
    def __init__(self, func):
        self.func = func
    
    def __call__(self, data: bytes):
        return self.func(data.tobytes() if isinstance(data, memoryview) else data)

    @classmethod
    def from_schema(cls, schema):
        text = schema["data"]
        if isinstance(text, memoryview):
            text = text.tobytes()
        name_decoders = generate_dynamic(schema["name"], text.decode("utf-8"))
        return cls(name_decoders[schema["name"]])


class MSGCodecFactory:
    def __init__(self):
        self.topic_codec = {}

    def import_schema(self, topic, schema):
        encoding = schema.get("encoding") or schema.get("encode")
        if encoding == enums.SchemaEncoding.PROTOBUF.value:
            self.topic_codec[topic] = ProtobufCodec.from_schema(schema)
        elif encoding == enums.SchemaEncoding.ROS2.value:
            self.topic_codec[topic] = Ros2Codec.from_schema(schema)
        elif encoding == enums.SchemaEncoding.JSON.value:
            self.topic_codec[topic] = JsonCodec()
        else:
            raise exceptions.UnsupportedError(f"Unsupported schema encoding: {schema['encoding']}")
    
    def __call__(self, data, topic):
        codec = self.topic_codec[topic]
        return codec(data)


default_codec_factory = MSGCodecFactory()


HAD_MSG_NAME = "mcapsdk.HeaderAndData"

FRAME_MSG_NAME = "mcapsdk.FrameHeader"

IMAGE_MSG_NAMES = ("ImageProto.Image", )

LIDAR_MSG_NAMES = ("LidarProto.LidarFrame", "sensors.LidarFrame")


def get_topic_type(topic, msg_name):
    if msg_name == "mcapsdk.HeaderAndData" and "data" in topic:
        if re.search("image", topic):
            return "image/data"
        if re.search("hesai|lidar", topic):
            return "lidar/data"
        return "proto"
    elif msg_name == "ImageProto.Image":
        return "image"
    elif msg_name in ("LidarProto.LidarFrame", "sensors.LidarFrame"):
        return "lidar"
    return "proto"
