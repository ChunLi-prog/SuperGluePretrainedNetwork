from functools import cached_property
from importlib import util as importlib_util
import os
from pathlib import Path

from cmdk.common import exceptions, settings
from cmdk.utils import tools
from cmdk.utils.mss_server import mss_server_cli


class MCAPObstructer:
    def __init__(self):
        self.base_dir = Path("/horizon-bucket/carizon_collect_jfs4/mcap_index/mcap_obstruct") / mss_server_cli.env

    def _get_entry_from_bucket_module(self):
        for core in (self.base_dir / "latest.py", self.base_dir / "latest_bak.py"):
            try:
                spec = importlib_util.spec_from_file_location(core.name, core)
                module = importlib_util.module_from_spec(spec)
                spec.loader.exec_module(module)
                return module.check
            except Exception:
                pass

    def _get_entry_from_bucket_exec(self):
        for core in (self.base_dir / "latest.py", self.base_dir / "latest_bak.py"):
            try:
                with open(core, "r") as fp:
                    core_content = fp.read()
                env = {}
                exec(core_content, env)
                return env["check"]
            except Exception:
                pass

    def _get_entry_from_server(self):
        core = mss_server_cli.get_obstruct_core()
        env = {}
        exec(core, env)
        return env["check"]

    @cached_property
    def entry(self):
        _entry = self._get_entry_from_bucket_exec()
        if not _entry:
            _entry = self._get_entry_from_server()
        return _entry

    def check_from_reader(self, mcap_path: Path) -> bool:
        if os.environ.get(settings.DISABLE_MCAP_OBSTRUCT_ENV) == "1":
            return 0
        
        if code := self.check(mcap_path):
            if code == 4:
                msg = f"{mcap_path} 不存在!"
            elif code != 0:
                msg = f"{mcap_path} 被检测为脏数据，需要重新转换!"
            raise exceptions.MCAPObstructedError(msg)

    def check(self, mcap_path: Path) -> bool:
        if not isinstance(mcap_path, tools.BucketPath):
            mcap_path = tools.BucketPath(mcap_path)
        if not mcap_path.is_bucket:
            return 0
        return self.entry(mcap_path.local_path)


obstructer = MCAPObstructer()
