import collections
import enum
from functools import cached_property
import io
import os
import struct
import heapq
import re
from typing import BinaryIO, Optional, Tuple, List, Dict, Sequence, Any
import zlib

from genson import SchemaBuilder
from google.protobuf.message import Message as ProtoBufMessage
import lz4.frame
import orjson
import zstandard

import cmdk
from cmdk.common import exceptions
from cmdk.common.enums import CompressionType, SchemaEncoding, ChannelEncoding
from cmdk.utils.msg_decoder import (
    CameraCodec,
    MSGCodecFactory,
    ProtobufCodec,
    JsonCodec,
    HAD_MSG_NAME,
    FRAME_MSG_NAME,
    IMAGE_MSG_NAMES,
    LIDAR_MSG_NAMES
)
from cmdk.mcap.msg import message
try:
    from cmdk.proto import mcapsdk_frame_pb2, mcapsdk_data_pb2
except ImportError:
    from cmdk.proto.compatible import mcapsdk_frame_pb2, mcapsdk_data_pb2


class _ChunkMsgOrderWraper:
    def __init__(self, data, is_chunk=True):
        self.data = data
        self.is_chunk = is_chunk
        self.ts = data["start_ts"] if is_chunk else data["log_time"]
    
    def __lt__(self, other: "_ChunkMsgOrderWraper"):
        return self.ts < other.ts


class _MetaMsgOrderWraper:
    def __init__(self, data, _type):
        self.data = data
        self.type = _type
        self.ts = data[0]["log_time"]
    
    def __lt__(self, other: "_MetaMsgOrderWraper"):
        return self.ts < other.ts


class _FrameMsgOrderWraper:
    def __init__(self, data):
        self.data = data
        self.ts = data[0]["log_time"]
    
    def __lt__(self, other: "_FrameMsgOrderWraper"):
        return self.ts < other.ts


class MCAPReadMixin:
    MAGIC = b"\x89MCAP0\r\n"
    
    @staticmethod
    def read_unknown(data, offset) -> int:
        length = struct.unpack_from("<Q", data, offset)[0]
        return offset + 8 + length

    @staticmethod
    def read(data, offset, size) -> Tuple[bytes, int]:
        end = offset + size
        return data[offset: end], end
    
    @staticmethod
    def read_1(data, offset) -> Tuple[int, int]:
        return struct.unpack_from("<B", data, offset)[0], offset + 1

    @staticmethod
    def read_2(data, offset) -> Tuple[int, int]:
        return struct.unpack_from("<H", data, offset)[0], offset + 2

    @staticmethod
    def read_4(data, offset) -> Tuple[int, int]:
        return struct.unpack_from("<I", data, offset)[0], offset + 4
    
    @staticmethod
    def read_8(data, offset) -> Tuple[int, int]:
        return struct.unpack_from("<Q", data, offset)[0], offset + 8

    @staticmethod
    def read_str(data, offset) -> Tuple[str, int]:
        length = struct.unpack_from("<I", data, offset)[0]
        end = offset + 4 + length
        return str(data[offset + 4: end], "utf-8"), end
    
    @staticmethod
    def read_timestamp(data, offset) -> Tuple[int, int]:
        timestamp = struct.unpack_from("<Q", data, offset)[0]
        return timestamp // 1000000, offset + 8
    
    @staticmethod
    def read_1_io(_io: BinaryIO) -> int:
        return struct.unpack("<B", _io.read(1))[0]

    @staticmethod
    def read_2_io(_io: BinaryIO) -> int:
        return struct.unpack("<H", _io.read(2))[0]

    @staticmethod
    def read_4_io(_io: BinaryIO) -> int:
        return struct.unpack("<I", _io.read(4))[0]

    @staticmethod
    def read_8_io(_io: BinaryIO) -> int:
        return struct.unpack("<Q", _io.read(8))[0]

    @staticmethod
    def read_str_io(_io: BinaryIO) -> str:
        length = struct.unpack("<I", _io.read(4))[0]
        return str(_io.read(length), "utf-8")

    @staticmethod
    def read_timestamp_io(_io: BinaryIO) -> int:
        timestamp = struct.unpack("<Q", _io.read(8))[0]
        return timestamp // 1000000

    @staticmethod
    def read_unknown_io(_io: BinaryIO) -> int:
        length = struct.unpack("<Q", _io.read(8))[0]
        _io.read(length)

    def _read_header_from_data(self, data, offset):
        _, offset = self.read_8(data, offset)
        profile, offset = self.read_str(data, offset)
        library, offset = self.read_str(data, offset)
        return {
            "profile": profile,
            "library": library
        }, offset

    def _read_header_from_io(self, _io: BinaryIO):
        _ = self.read_8_io(_io)
        profile = self.read_str_io(_io)
        library = self.read_str_io(_io)
        return {
            "profile": profile,
            "library": library
        }

    def _read_footer_from_data(self, data, offset):
        _, offset = self.read_8(data, offset)
        summary_start, offset = self.read_8(data, offset)
        summary_offset_start, offset = self.read_8(data, offset)
        summary_crc, offset = self.read_4(data, offset)
        return {
            "summary_start": summary_start,
            "summary_offset_start": summary_offset_start,
            "summary_crc": summary_crc
        }, offset
    
    def _read_chunk_from_io(self, _io: BinaryIO):
        _ = self.read_8_io(_io)
        message_start_time = self.read_timestamp_io(_io)
        message_end_time = self.read_timestamp_io(_io)
        uncompressed_size = self.read_8_io(_io)
        uncompressed_crc = self.read_4_io(_io)
        compression = self.read_str_io(_io)
        data_length = self.read_8_io(_io)
        data = _io.read(data_length)
        return {
            "message_start_time": message_start_time,
            "message_end_time": message_end_time,
            "compressed_size": data_length,
            "uncompressed_size": uncompressed_size,
            "uncompressed_crc": uncompressed_crc,
            "compression": compression,
            "data": data
        }

    def _iter_records_from_chunk(self, chunk):
        data = memoryview(self.chunk_decompress(chunk["data"], chunk["compression"], chunk["uncompressed_size"]))
        offset = 0
        offset_end = len(data)
        while offset < offset_end:
            code, offset = self.read_1(data, offset)
            if code == OperationCode.MESSAGE.value:
                message, offset = self._read_message_from_data(data, offset)
                yield message, "msg"
            elif code == OperationCode.SCHEMA.value:
                schema, offset = self._read_schema_from_data(data, offset)
                yield schema, "schema"
            elif code == OperationCode.CHANNEL.value:
                channel, offset = self._read_channel_from_data(data, offset)
                yield channel, "channel"
            else:
                offset = self.read_unknown(data, offset)

    def _read_records_from_chunk(self, chunk):
        channels = []
        msgs = []
        schemas = []
        for record in self._iter_records_from_chunk(chunk):
            if record[1] == "msg":
                msgs.append(record[0])
            elif record[1] == "channel":
                channels.append(record[0])
            elif record[1] == "schema":
                schemas.append(record[0])
        return channels, schemas, msgs

    @staticmethod
    def chunk_decompress(data, compression, uncompressed_size=None) -> bytes:
        if not compression:
            return data
        elif compression == "zstd":
            return zstandard.decompress(data, uncompressed_size)
        elif compression == "lz4":
            return lz4.frame.decompress(data)
        else:
            raise exceptions.UnsupportedError(f"Unsupported compression type: {compression}!")

    def _read_message_index_from_io(self, _io: BinaryIO):
        offset = _io.tell() - 1
        length = self.read_8_io(_io)
        channel_id = self.read_2_io(_io)
        records_length = self.read_4_io(_io)
        records_offset = 0
        records = []
        while records_offset < records_length:
            timestamp = self.read_timestamp_io(_io)
            offset = self.read_8_io(_io)
            records_offset += 16
            records.append({
                "timestamp": timestamp,
                "offset": offset
            })
        return {
            "channel_id": channel_id,
            "records": records,
            "_op_offset": offset,
            "_op_length": length + 1,
        }

    def _read_schema_from_data(self, data, offset):
        _, offset = self.read_8(data, offset)
        id, offset = self.read_2(data, offset)
        name, offset = self.read_str(data, offset)
        encoding, offset = self.read_str(data, offset)
        data_length, offset = self.read_4(data, offset)
        data, offset = self.read(data, offset, data_length)
        schema = {
            "id": id, 
            "name": name,
            "encoding": encoding,
            "data": data
        }
        return schema, offset

    def _read_channel_from_data(self, data, offset):
        _, offset = self.read_8(data, offset)
        id, offset = self.read_2(data, offset)
        schema_id, offset = self.read_2(data, offset)
        topic, offset = self.read_str(data, offset)
        message_encoding, offset = self.read_str(data, offset)
        metadata_length, offset = self.read_4(data, offset)
        metadata = dict()
        offset_end = offset + metadata_length
        while offset < offset_end:
            key, offset = self.read_str(data, offset)
            value, offset = self.read_str(data, offset)
            metadata[key] = value
        channel = {
            "id": id, 
            "schema_id": schema_id,
            "topic": topic,
            "encoding": message_encoding,
            "metadata": metadata
        }
        return channel, offset

    def _read_metadata_from_io(self, _io: BinaryIO):
        length = self.read_8_io(_io)
        name = self.read_str_io(_io)
        metadata_length = self.read_4_io(_io)
        metadata_end = _io.tell() + metadata_length
        metadata = {}
        while _io.tell() < metadata_end:
            key = self.read_str_io(_io)
            value = self.read_str_io(_io)
            metadata[key] = value
        return {
            "name": name,
            "metadata": metadata,
            "_op_length": length + 1,
        }
    
    def _read_attachment_from_io(self, _io: BinaryIO):
        length = self.read_8_io(_io)
        log_time = self.read_timestamp(_io)
        create_time = self.read_timestamp(_io)
        name = self.read_str_io(_io)
        media_type = self.read_str_io(_io)
        data_length = self.read_8_io(_io)
        data = _io.read(data_length)
        _ = self.read_4_io(_io)
        return {
            "log_time": log_time,
            "create_time": create_time,
            "name": name,
            "media_type": media_type,
            "data": data,
            "_op_length": length + 1,
        }

    def _read_statistics_from_data(self, data, offset):
        _, offset = self.read_8(data, offset)
        message_count, offset = self.read_8(data, offset)
        schema_count, offset = self.read_2(data, offset)
        channel_count, offset = self.read_4(data, offset)
        attachment_count, offset = self.read_4(data, offset)
        metadata_count, offset = self.read_4(data, offset)
        chunk_count, offset = self.read_4(data, offset)
        
        message_start_time, offset = self.read_timestamp(data, offset)
        message_end_time, offset = self.read_timestamp(data, offset)
        channel_message_counts_length, offset = self.read_4(data, offset)
        channel_message_counts = dict()
        offset_end = offset + channel_message_counts_length
        while offset < offset_end:
            channel_id, offset = self.read_2(data, offset)
            channel_message_count, offset = self.read_8(data, offset)
            channel_message_counts[channel_id] = channel_message_count
        
        statistics = {
            "message_count": message_count,
            "schema_count": schema_count,
            "channel_count": channel_count,
            "attachment_count": attachment_count,
            "metadata_count": metadata_count,
            "chunk_count": chunk_count,
            "message_start_time": message_start_time,
            "message_end_time": message_end_time,
            "channel_message_counts": channel_message_counts
        }
        return statistics, offset

    def _read_chunk_index_from_data(self, data, offset):
        _, offset = self.read_8(data, offset)
        message_start_time, offset = self.read_timestamp(data, offset)
        message_end_time, offset = self.read_timestamp(data, offset)
        chunk_start_offset, offset = self.read_8(data, offset)
        chunk_length, offset = self.read_8(data, offset)
        message_index_offsets_length, offset = self.read_4(data, offset)
        message_index_offsets = dict()
        
        offsets_end = offset + message_index_offsets_length
        while offset < offsets_end:
            channel_id, offset = self.read_2(data, offset)
            channel_offset, offset = self.read_8(data, offset)
            message_index_offsets[channel_id] = channel_offset
        message_index_length, offset = self.read_8(data, offset)
        compression, offset = self.read_str(data, offset)
        compressed_size, offset = self.read_8(data, offset)
        uncompressed_size, offset = self.read_8(data, offset)
        chunk_index = {
            "start_ts": message_start_time,
            "end_ts": message_end_time,
            "offset": chunk_start_offset,
            "size": chunk_length,
            "message_index_offsets": message_index_offsets,
            "message_index_length": message_index_length,
            "compression": compression,
            "compressed_size": compressed_size,
            "uncompressed_size": uncompressed_size
        }
        return chunk_index, offset
    
    def _read_metadata_index_from_data(self, data, offset):
        _, offset = self.read_8(data, offset)
        metadata_offset, offset = self.read_8(data, offset)
        metadata_length, offset = self.read_8(data, offset)
        name, offset = self.read_str(data, offset)
        return {
            "offset": metadata_offset,
            "length": metadata_length,
            "name": name
        }, offset

    def _read_message_from_data(self, data, offset):
        chunk_offset = offset - 1
        length, offset = self.read_8(data, offset)
        channel_id, offset = self.read_2(data, offset)
        sequence, offset = self.read_4(data, offset)
        log_time, offset = self.read_timestamp(data, offset)
        publish_time, offset = self.read_timestamp(data, offset)
        data, offset = self.read(data, offset, length - 22)
        return {
            "channel_id": channel_id,
            "sequence": sequence,
            "log_time": log_time,
            "publish_time": publish_time,
            "data": data,
            "_coffset": chunk_offset,
        }, offset
    
    def _read_summary_from_data(self, data, offset=0, length=None):
        result = {}
        opcode_map = {
            OperationCode.SCHEMA.value: ("schemas", self._read_schema_from_data),
            OperationCode.CHANNEL.value: ("channels", self._read_channel_from_data),
            OperationCode.STATISTICS.value: ("statistics", self._read_statistics_from_data),
            OperationCode.CHUNK_INDEX.value: ("chunk_index", self._read_chunk_index_from_data),
            OperationCode.METADATA_INDEX.value: ("metadata_index", self._read_metadata_index_from_data),
        }
        while True:
            if length is not None and offset >= length:
                break
            opcode, offset = self.read_1(data, offset)
            if opcode in opcode_map:
                name, func = opcode_map[opcode]
                read_result, offset = func(data, offset)
                result[name] = read_result
            elif opcode == OperationCode.SUMMARY_OFFSET.value:
                break
            else:
                offset = self.read_unknown(data, offset)
        return result, offset


class MCAPReadHandler:
    def __init__(self, stream: BinaryIO, stream_name: str, use_gpu="auto"):
        self.stream = stream
        self.stream_name = stream_name
        self.use_gpu = use_gpu
        self.summary = {
            "schemas": {},
            "channels": {},
            "statistics": None,
            "chunk_index": [],
            "metadata": {},
        }
        self.init_summary()
        self.init_decoder()
    
    def init_summary(self):
        self.stream.seek(-37, io.SEEK_END)
        footer_offset = self.stream.tell()
        footer_data = self.stream.read(29)
        if footer_data[0] != 0x02:
            raise exceptions.InvalidMCAPError(f"{self.stream_name} has invalid footer opcode {footer_data[0]}!")
        
        summary_offset, _ = self.read_8(footer_data, 9)
        
        self.stream.seek(summary_offset, io.SEEK_SET)
        summary_size = footer_offset - summary_offset
        summary_data = memoryview(self.stream.read(summary_size))
        
        offset = 0
        part_map = {
            0x03: self.read_schema,
            0x04: self.read_channel,
            0x0B: self.read_statistics,
            0x08: self.read_chunk_index,
            0x0d: self.read_metadata_by_index,
        }
        
        while offset < summary_size:
            code, offset = self.read_1(summary_data, offset)
            if part_reader := part_map.get(code):
                offset = part_reader(summary_data, offset)
            else:
                offset = self.read_unknown(summary_data, offset)
        self.summary["chunk_index"].sort(key=lambda v: v["start_ts"])

        self._frame_topics = {}
        _topics_frame = {}
        if frame_msg_map := self.summary["metadata"].get("frame_msg_map"):
            for frame_name, topics in frame_msg_map.items():
                self._frame_topics[frame_name] = set(topics.split("###"))
                for topic in self._frame_topics[frame_name]:
                    _topics_frame[topic] = frame_name
        
        self._all_topics = {}
        _topic_msg_name = {
            info["topic"]: self.summary["schemas"][info["schema_id"]]["name"]
            for info in self.summary["channels"].values()
        }
        for topic, name in _topic_msg_name.items():
            if name == FRAME_MSG_NAME and topic not in self._frame_topics and f"{topic}/data" not in _topic_msg_name:
                self._frame_topics[topic] = set()
        
        for _id, info in self.summary["channels"].items():
            topic = info["topic"]
            topic_type = "normal"
            value = {
                "channel_id": _id,
                "name": _topic_msg_name[topic],
                "message_count": self.summary["statistics"]["channel_message_counts"].get(_id, 0),
            }
            if topic in self._frame_topics:
                topic_type = "frame"
                value["meta_topics"] = self._frame_topics[topic]
            if value["name"] != HAD_MSG_NAME:
                had_topic = f"{topic}/data"
                if _topic_msg_name.get(had_topic) == HAD_MSG_NAME:
                    value["had_topic"] = had_topic
                    topic_type = "meta"
                    self._all_topics.setdefault(had_topic, {})["type"] = "had"
                    self._all_topics.setdefault(had_topic, {})["meta_topic"] = topic
            if topic in _topics_frame:
                value["frame_topic"] = _topics_frame[topic]
            self._all_topics.setdefault(topic, {}).update(value)
            self._all_topics.setdefault(topic, {}).setdefault("type", topic_type)
    
    def init_decoder(self):
        self._topic_msg_class = {}
        self.codec_factory = MSGCodecFactory()
        self._image_channels = set()
        self._fg_video_channels = set()
        for channel_id, info in self.summary["channels"].items():
            if self.summary["statistics"]["channel_message_counts"].get(channel_id, 0) == 0:
                continue
            schema = self.summary["schemas"][info["schema_id"]]
            topic = info["topic"]
            self.codec_factory.import_schema(topic, schema)
            if schema["name"] in IMAGE_MSG_NAMES:
                if _image_topic_info := self._all_topics.get(f"{topic}/data"):
                    self._image_channels.add(_image_topic_info["channel_id"])
                self._topic_msg_class[topic] = message.ImageMessage
            elif schema["name"] in LIDAR_MSG_NAMES:
                self._topic_msg_class[topic] = message.LidarMessage
            elif schema["name"] == FRAME_MSG_NAME:
                self._topic_msg_class[topic] = message.Frame
            else:
                if schema["name"].endswith("CompressedVideo"):
                    self._topic_msg_class[topic] = message.FoxgloveCompressedVideoMessage
                    self._fg_video_channels.add(channel_id)
                else:
                    self._topic_msg_class[topic] = message.Message

    @cached_property
    def image_decoders(self) -> dict:
        result = {}
        for topic, data in self.get_image_key_data().items():
            decoder = CameraCodec()
            if data:
                decoder.set_extra(data)

            if meta_topic := self._all_topics[topic].get("meta_topic"):
                result[meta_topic] = decoder
            else:
                result[topic] = decoder
        return result

    @cached_property
    def image_decoders_gpu(self) -> dict:
        result = {}
        for topic, data_list in self.get_image_key_data_gpu(self._image_channels).items():
            meta_topic = self._all_topics[topic]["meta_topic"]
            decoder = CameraCodec()
            if data_list:
                decoder.set_extras(data_list)
            result[meta_topic] = decoder
        return result
    
    def get_start_timestamp(self) -> int:
        return self.summary["statistics"]["message_start_time"]
    
    def get_end_timestamp(self) -> int:
        return self.summary["statistics"]["message_end_time"]
        
    def iter_raw_messages(self,
                          start_timestamp_ms: int = None,
                          end_timestamp_ms: int = None,
                          channels: Sequence[int] = None):
        msg_queue = []
        for chunk in self.summary["chunk_index"]:
            if start_timestamp_ms and chunk["end_ts"] < start_timestamp_ms:
                continue
            if end_timestamp_ms and chunk["start_ts"] > end_timestamp_ms:
                continue
            if channels is not None:
                for channel_id in chunk["message_index_offsets"]:
                    if channel_id in channels:
                        msg_queue.append(_ChunkMsgOrderWraper(chunk, True))
                        break
            else:
                msg_queue.append(_ChunkMsgOrderWraper(chunk, True))

        channel_infos = self.summary["channels"]
        while msg_queue:
            item = heapq.heappop(msg_queue)
            if item.is_chunk:
                for msg in self.read_chunk_messages(item.data):
                    if channels and msg["channel_id"] not in channels:
                        continue
                    if start_timestamp_ms and msg["log_time"] < start_timestamp_ms:
                        continue
                    if end_timestamp_ms and msg["log_time"] > end_timestamp_ms:
                        continue
                    heapq.heappush(msg_queue, _ChunkMsgOrderWraper(msg, False))
            else:
                item.data["topic"] = channel_infos[item.data["channel_id"]]["topic"]
                yield item.data
    
    def iter_raw_msgs_by_topics(self, start_timestamp_ms: int = None, end_timestamp_ms: int = None, topics: Sequence[str] = None):
        channels = None
        if topics is not None:
            channels = [self._all_topics[topic]["channel_id"] for topic in topics if topic in self._all_topics]
        for msg in self.iter_raw_messages(start_timestamp_ms, end_timestamp_ms, channels):
            yield message.Message({"meta": msg}, self)

    def get_image_key_data_gpu(self, channel_ids):
        result = {}
        if not channel_ids:
            return result
        buffer = {}
        key_item = {}
        for chunk in self.summary["chunk_index"]:
            for msg in self.read_chunk_messages(chunk):
                channel_id = msg["channel_id"]
                if channel_id not in channel_ids:
                    continue
                topic = self.summary["channels"][channel_id]["topic"]
                decoder = self.codec_factory.topic_codec[topic]
                pb = decoder((msg["data"]))
                if len(pb.data_blocks) > 0:
                    buffer.setdefault(topic, []).append(pb.data_blocks[0].data)
                    if self.use_gpu is True:
                        if pb.data_blocks[0].data[4] & 0x7e == 0x40:
                            key_item.setdefault(topic, len(buffer[topic]) - 1)
                        if len(buffer[topic]) == 30:
                            result[topic] = (buffer[topic], key_item[topic])
                    else:
                        if pb.data_blocks[0].data[4] & 0x7e == 0x40:
                            result[topic] = (buffer[topic], len(buffer[topic]) - 1)
                else:
                    result[topic] = None
                if len(result) == len(channel_ids):
                    return result
        return result
  
    def get_image_key_data(self):
        result = {}
        channels = self._image_channels | self._fg_video_channels
        if not channels:
            return result
        for chunk in self.summary["chunk_index"]:
            for msg in self.read_chunk_messages(chunk):
                channel_id = msg["channel_id"]
                if channel_id not in channels:
                    continue
                topic = self.summary["channels"][channel_id]["topic"]
                decoder = self.codec_factory.topic_codec[topic]
                pb = decoder((msg["data"]))
                if channel_id in self._image_channels:
                    if len(pb.data_blocks) > 0:
                        if pb.data_blocks[0].data[4] & 0x7e == 0x40:
                            result[topic] = pb.data_blocks[0].data
                    else:
                        result[topic] = None
                elif channel_id in self._fg_video_channels:
                    if pb.data[4] & 0x7e == 0x40:
                        result[topic] = pb.data
                else:
                    result[topic] = None
                if len(result) == len(channels):
                    return result
        return result
  
    def iter_messages(self, start_timestamp_ms: int = None, end_timestamp_ms: int = None, topics: List[str] = None):
        select_topics = {}
        if topics is None:
            select_topics = self._all_topics
        else:
            for topic in topics:
                if info := self._all_topics.get(topic):
                    select_topics[topic] = info
                    if info["type"] == "meta":
                        had_topic = self._all_topics[topic]["had_topic"]
                        select_topics[had_topic] = self._all_topics[had_topic]
                    elif info["type"] == "frame":
                        for meta_topic in info.get("meta_topics"):
                            select_topics[meta_topic] = self._all_topics[meta_topic]
                            had_topic = self._all_topics[meta_topic]["had_topic"]
                            select_topics[had_topic] = self._all_topics[had_topic]
        if not select_topics:
            return
        frame_topics = set()
        none_frame_topics = {}
        meta_topics_queues = {}
        had_map = {}
        normal_topics = set()
        select_channels = set()
        for topic, info in select_topics.items():
            if self.summary["statistics"]["channel_message_counts"].get(info["channel_id"], 0) > 0:
                select_channels.add(info["channel_id"])
            if info["type"] == "frame":
                frame_topics.add(topic)
            elif info["type"] == "meta":
                if info.get("frame_topic") in select_topics:
                    meta_topics_queues[topic] = collections.defaultdict(dict)
                else:
                    none_frame_topics[topic] = {}
            elif info["type"] == "had":
                had_map[topic] = info["meta_topic"]
            else:
                normal_topics.add(topic)

        buffer_size = int((len(frame_topics) + len(none_frame_topics)) * 1.5 + 1)
        buffer = []
        pop_count = 0
        buffer_tail = 0
        for _raw_msg in self.iter_raw_messages(start_timestamp_ms, end_timestamp_ms, select_channels):
            topic = _raw_msg["topic"]
            _type = "meta"
            if topic in had_map:
                topic = had_map[topic]
                _type = "had"
            _seq = _raw_msg["sequence"]
            if topic in meta_topics_queues:
                meta_topics_queues[topic][_seq][_type] = _raw_msg
            elif topic in none_frame_topics:
                if _seq in none_frame_topics[topic]:
                    buffer[none_frame_topics[topic][_seq] - pop_count]._raw_msg[_type] = _raw_msg
                else:
                    buffer.append(self._topic_msg_class[topic]({_type: _raw_msg}, self))
                    none_frame_topics[topic][_seq] = buffer_tail
                    buffer_tail += 1
            elif topic in frame_topics:
                buffer.append(message.Frame([_raw_msg], self))
                buffer_tail += 1
            elif topic in normal_topics:
                buffer.append(self._topic_msg_class[topic]({_type: _raw_msg}, self))
                buffer_tail += 1

            if len(buffer) >= buffer_size:
                while buffer:
                    item = buffer[0]
                    if isinstance(item, message.Frame):
                        for msg_info in item.proto.msg_list:
                            if len(meta_topics_queues[msg_info.topic].get(msg_info.mcap_sequence, {})) == 2:
                                _msg = meta_topics_queues[msg_info.topic].pop(msg_info.mcap_sequence)
                                item._raw_msg.append(self._topic_msg_class[msg_info.topic](_msg, self, item))
                        if len(item._raw_msg) > len(item.proto.msg_list):
                            yield buffer.pop(0)
                            pop_count += 1
                        else:
                            break
                    else:
                        if len(item._raw_msg) == 2 or item._raw_msg.get("meta", {}).get("topic") in normal_topics:
                            yield buffer.pop(0)
                            pop_count += 1
                        else:
                            break
        while buffer:
            item = buffer.pop(0)
            if isinstance(item, message.Frame):
                for msg_info in item.proto.msg_list:
                    if _msg := meta_topics_queues[msg_info.topic].pop(msg_info.mcap_sequence, None):
                        item._raw_msg.append(self._topic_msg_class[msg_info.topic](_msg, self, item))
                yield item
            else:
                yield item

    def read_schema(self, data, offset):
        _, offset = self.read_8(data, offset)
        id, offset = self.read_2(data, offset)
        name, offset = self.read_str(data, offset)
        encoding, offset = self.read_str(data, offset)
        data_length, offset = self.read_4(data, offset)
        data, offset = self.read(data, offset, data_length)
        self.summary["schemas"][id] = {
            "id": id, 
            "name": name,
            "encoding": encoding,
            "data": data
        }
        return offset
    
    def read_channel(self, data, offset):
        _, offset = self.read_8(data, offset)
        id, offset = self.read_2(data, offset)
        schema_id, offset = self.read_2(data, offset)
        topic, offset = self.read_str(data, offset)
        message_encoding, offset = self.read_str(data, offset)
        metadata_length, offset = self.read_4(data, offset)
        metadata = dict()
        offset_end = offset + metadata_length
        while offset < offset_end:
            key, offset = self.read_str(data, offset)
            value, offset = self.read_str(data, offset)
            metadata[key] = value
        self.summary["channels"][id] = {
            "id": id, 
            "schema_id": schema_id,
            "topic": topic,
            "encoding": message_encoding,
            "metadata": metadata
        }
        return offset
    
    def read_statistics(self, data, offset):
        _, offset = self.read_8(data, offset)
        message_count, offset = self.read_8(data, offset)
        schema_count, offset = self.read_2(data, offset)
        channel_count, offset = self.read_4(data, offset)
        attachment_count, offset = self.read_4(data, offset)
        metadata_count, offset = self.read_4(data, offset)
        chunk_count, offset = self.read_4(data, offset)
        
        message_start_time, offset = self.read_timestamp(data, offset)
        message_end_time, offset = self.read_timestamp(data, offset)
        channel_message_counts_length, offset = self.read_4(data, offset)
        channel_message_counts = dict()
        offset_end = offset + channel_message_counts_length
        while offset < offset_end:
            channel_id, offset = self.read_2(data, offset)
            channel_message_count, offset = self.read_8(data, offset)
            channel_message_counts[channel_id] = channel_message_count
        
        self.summary["statistics"] = {
            "message_count": message_count,
            "schema_count": schema_count,
            "channel_count": channel_count,
            "attachment_count": attachment_count,
            "metadata_count": metadata_count,
            "chunk_count": chunk_count,
            "message_start_time": message_start_time,
            "message_end_time": message_end_time,
            "channel_message_counts": channel_message_counts
        }
        return offset
    
    def read_chunk_index(self, data, offset):
        _, offset = self.read_8(data, offset)
        message_start_time, offset = self.read_timestamp(data, offset)
        message_end_time, offset = self.read_timestamp(data, offset)
        chunk_start_offset, offset = self.read_8(data, offset)
        chunk_length, offset = self.read_8(data, offset)
        message_index_offsets_length, offset = self.read_4(data, offset)
        message_index_offsets = dict()
        
        offsets_end = offset + message_index_offsets_length
        while offset < offsets_end:
            channel_id, offset = self.read_2(data, offset)
            channel_offset, offset = self.read_8(data, offset)
            message_index_offsets[channel_id] = channel_offset
        message_index_length, offset = self.read_8(data, offset)
        compression, offset = self.read_str(data, offset)
        compressed_size, offset = self.read_8(data, offset)
        uncompressed_size, offset = self.read_8(data, offset)
        self.summary["chunk_index"].append({
            "start_ts": message_start_time,
            "end_ts": message_end_time,
            "offset": chunk_start_offset,
            "size": chunk_length,
            "message_index_offsets": message_index_offsets,
            "message_index_length": message_index_length,
            "compression": compression,
            "compressed_size": compressed_size,
            "uncompressed_size": uncompressed_size
        })
        return offset

    @cached_property
    def message_indexes(self):
        msg_index = {}
        for chunk_item, chunk_index in enumerate(self.summary["chunk_index"]):
            offset = float("inf")
            for _offset in chunk_index["message_index_offsets"].values():
                offset = min(offset, _offset)

            self.stream.seek(offset)
            data = memoryview(self.stream.read(chunk_index["message_index_length"]))

            offset = 0
            offsets_end = len(data)

            while offset < offsets_end:
                _, offset = self.read_1(data, offset)
                length, offset = self.read_8(data, offset)
                channel_id, offset = self.read_2(data, offset)
                records_length, records_offset = self.read_4(data, offset)
                records_offset_end = records_offset + records_length

                while records_offset < records_offset_end:
                    msg_ts, records_offset = self.read_timestamp(data, records_offset)
                    msg_offset, records_offset = self.read_8(data, records_offset)
                    msg_index.setdefault(channel_id, {})[msg_ts] = [chunk_item, msg_offset]
                offset = records_offset
        return msg_index

    def read_metadata_by_index(self, data, offset):
        _, offset = self.read_8(data, offset)
        metadata_offset, offset = self.read_8(data, offset)
        metadata_length, offset = self.read_8(data, offset)
        name, idx_offset = self.read_str(data, offset)
        
        self.stream.seek(metadata_offset + 9)
        meta_data = self.stream.read(metadata_length - 9)
        
        name, offset = self.read_str(meta_data, 0)
        metadata_length, offset = self.read_4(meta_data, offset)
        
        metadata = dict()
        offsets_end = offset + metadata_length
        while offset < offsets_end:
            key, offset = self.read_str(meta_data, offset)
            value, offset = self.read_str(meta_data, offset)
            metadata[key] = value
        self.summary["metadata"].setdefault(name, dict()).update(metadata)
        return idx_offset
    
    def read_message(self, data, offset):
        length, offset = self.read_8(data, offset)
        channel_id, offset = self.read_2(data, offset)
        sequence, offset = self.read_4(data, offset)
        log_time, offset = self.read_timestamp(data, offset)
        publish_time, offset = self.read_timestamp(data, offset)
        data, offset = self.read(data, offset, length - 22)
        return {
            "channel_id": channel_id,
            "sequence": sequence,
            "log_time": log_time,
            "publish_time": publish_time,
            "data": data
        }, offset
    
    def read_message_from_stream(self, offset):
        self.stream.seek(offset, io.SEEK_SET)
        data = self.stream.read(9)
        opcode, _ = self.read_1(data, 0)
        assert opcode == OperationCode.MESSAGE.value, f"Invalid message opcode {opcode}!"
        length, _ = self.read_8(data, 1)
        
        data = self.stream.read(length)
        offset = 0
        channel_id, offset = self.read_2(data, offset)
        sequence, offset = self.read_4(data, offset)
        log_time, offset = self.read_timestamp(data, offset)
        publish_time, offset = self.read_timestamp(data, offset)
        data, offset = self.read(data, offset, length - 22)
        return {
            "channel_id": channel_id,
            "sequence": sequence,
            "log_time": log_time,
            "publish_time": publish_time,
            "data": data
        }
        
    def read_chunk_messages(self, info):
        compression = info["compression"]
        self.stream.seek(info["offset"] + 49 + len(compression), io.SEEK_SET)
        data = self.stream.read(info["compressed_size"])
        
        data = memoryview(self.chunk_decompress(data, compression, info["uncompressed_size"]))
        offset = 0
        offset_end = len(data)
        while offset < offset_end:
            code, offset = self.read_1(data, offset)
            if code == 0x05:
                message, offset = self.read_message(data, offset)
                yield message
            else:
                offset = self.read_unknown(data, offset)
    
    def read_message_by_timestamp(self, topic: str, timestamp_ms: int):
        channels = []
        if topic_info := self._all_topics.get(topic):
            if topic_info["type"] == "meta":
                channels = [
                    (topic_info["channel_id"], topic_info["type"]),
                    (self._all_topics[topic_info["had_topic"]]["channel_id"], "had")
                ]
        if not channels:
            return
        
        msg_indexes = self.message_indexes
        ch_msg_indexs = dict()
        for channel_id, _type in channels:
            msg_index = msg_indexes.get(channel_id, {}).get(timestamp_ms)
            if not msg_index:
                return None
            ch_msg_indexs.setdefault(msg_index[0], []).append((msg_index[1], _type))
        
        channel_infos = self.summary["channels"]
        
        msgs = {}
        for chunk_idx, msg_offsets in ch_msg_indexs.items():
            chunk_info = self.summary["chunk_index"][chunk_idx]
            compression = chunk_info["compression"]
            base_offset = chunk_info["offset"] + 49 + len(compression)
            if compression:
                self.stream.seek(base_offset, io.SEEK_SET)
                data = self.chunk_decompress(
                    self.stream.read(chunk_info["compressed_size"]), compression, chunk_info["uncompressed_size"])
                for offset, _type in msg_offsets:
                    opcode, offset = self.read_1(data, offset)
                    assert opcode == 0x05, f"Invalid message opcode {opcode}!"
                    _msg, _ = self.read_message(data, offset)
                    _msg["topic"] = channel_infos[_msg["channel_id"]]["topic"]
                    msgs[_type] = _msg
            else:
                msg_offsets.sort()
                for offset, _type in msg_offsets:
                    _msg = self.read_message_from_stream(base_offset + offset)
                    _msg["topic"] = channel_infos[_msg["channel_id"]]["topic"]
                    msgs[_type] = _msg
                    
        return self._topic_msg_class[topic](msgs, self)
    
    @staticmethod
    def chunk_decompress(data, compression, uncompressed_size=None) -> bytes:
        if not compression:
            return data
        elif compression == "zstd":
            return zstandard.decompress(data, uncompressed_size)
        elif compression == "lz4":
            return lz4.frame.decompress(data)
        else:
            raise exceptions.UnsupportedError(f"Unsupported compression type: {compression}!")
    
    def read_unknown(self, data, offset) -> int:
        length, offset = self.read_8(data, offset)
        _, offset = self.read(data, offset, length)
        return offset
    
    @staticmethod
    def read(data, offset, size) -> Tuple[bytes, int]:
        end = offset + size
        return data[offset: end], end
    
    @staticmethod
    def read_1(data, offset) -> Tuple[int, int]:
        return struct.unpack_from("<B", data, offset)[0], offset + 1

    @staticmethod
    def read_2(data, offset) -> Tuple[int, int]:
        return struct.unpack_from("<H", data, offset)[0], offset + 2

    @staticmethod
    def read_4(data, offset) -> Tuple[int, int]:
        return struct.unpack_from("<I", data, offset)[0], offset + 4
    
    @staticmethod
    def read_8(data, offset) -> Tuple[int, int]:
        return struct.unpack_from("<Q", data, offset)[0], offset + 8

    @staticmethod
    def read_str(data, offset) -> Tuple[str, int]:
        length = struct.unpack_from("<I", data, offset)[0]
        end = offset + 4 + length
        return str(data[offset + 4: end], "utf-8"), end
    
    @staticmethod
    def read_timestamp(data, offset) -> Tuple[int, int]:
        timestamp = struct.unpack_from("<Q", data, offset)[0]
        return timestamp // 1000000, offset + 8

    @staticmethod
    def is_ts_not_overlap(target: int, start_ts: int = None, end_ts: int = None) -> bool:
        return target < start_ts or target > end_ts

    @staticmethod
    def is_chunk_not_overlap(chunk: dict, start_ts: int, end_ts: int) -> bool:
        return end_ts < chunk["start_ts"] or chunk["end_ts"] < start_ts


class StreamWriter:
    def __init__(self, stream):
        self.stream = stream

    def write_1(self, value: int):
        self.stream.write(value.to_bytes(1, "little"))

    def write_2(self, value: int):
        self.stream.write(value.to_bytes(2, "little"))

    def write_4(self, value: int):
        self.stream.write(value.to_bytes(4, "little"))

    def write_8(self, value: int):
        self.stream.write(value.to_bytes(8, "little"))
    
    def write_timestamp(self, timestamp_ms: int):
        self.stream.write((timestamp_ms * 1000000).to_bytes(8, "little"))

    def write_str(self, data: str):
        in_bytes = data.encode()
        self.stream.write(len(in_bytes).to_bytes(4, "little"))
        self.stream.write(in_bytes)

    def write(self, data: bytes):
        self.stream.write(data)

    @property
    def offset(self) -> int:
        return self.stream.tell()

    def seek(self, offset: int, where=os.SEEK_SET):
        self.stream.seek(offset, where=where)

    def flush(self):
        self.stream.flush()


class BufferWriter(StreamWriter):
    def __init__(self):
        self.op_offset = 0
        super().__init__(io.BytesIO())

    def start_write_record(self, opcode: "OperationCode"):
        self.op_offset = self.stream.tell()
        self.stream.write(opcode.value.to_bytes(9, 'little'))

    def write_record_done(self):
        curr_pos = self.stream.tell()
        length = curr_pos - self.op_offset - 9
        self.stream.seek(self.op_offset + 1)
        self.stream.write(length.to_bytes(8, "little"))
        self.stream.seek(curr_pos)

    def dump(self):
        _bytes = self.stream.getvalue()
        self.stream.close()
        self.stream = io.BytesIO()
        self.op_offset = 0
        return _bytes


class MCAPWriteMixin:
    LIBRARY = f"CMDK {cmdk.__version__}"

    def _write_header(self, profile, library, buffer):
        buffer.start_write_record(OperationCode.HEADER)
        buffer.write_str(profile)
        buffer.write_str(library)
        buffer.write_record_done()

    def _write_channel(self, info, buffer):
        buffer.start_write_record(OperationCode.CHANNEL)
        buffer.write_2(info["id"])
        buffer.write_2(info["schema_id"])
        buffer.write_str(info["topic"])
        buffer.write_str(info["encoding"])
        meta_length = 0
        for key, value in info["metadata"].items():
            meta_length += len(key.encode()) + len(value.encode()) + 8
        buffer.write_4(meta_length)
        for key, value in info["metadata"].items():
            buffer.write_str(key)
            buffer.write_str(value)
        buffer.write_record_done()

    def _write_schema(self, info, buffer):
        buffer.start_write_record(OperationCode.SCHEMA)
        buffer.write_2(info["id"])
        buffer.write_str(info["name"])
        buffer.write_str(info["encoding"])
        buffer.write_4(len(info["data"]))
        buffer.write(info["data"])
        buffer.write_record_done()
    
    def _write_message(self, info, buffer):
        buffer.start_write_record(OperationCode.MESSAGE)
        buffer.write_2(info["sequence"])
        buffer.write_4(info["channel_id"])
        buffer.write_timestamp(info["log_time"])
        buffer.write_timestamp(info["publish_time"])
        buffer.write(info["data"])
        buffer.write_record_done()
    
    def _write_chunk(self, info, buffer):
        buffer.start_write_record(OperationCode.CHUNK)
        buffer.write_timestamp(info["message_start_time"])
        buffer.write_timestamp(info["message_end_time"])
        buffer.write_8(info["uncompressed_size"])
        buffer.write_4(info["uncompressed_crc"])
        buffer.write_str(info["compression"])
        buffer.write_8(len(info["data"]))
        buffer.write(info["data"])
        buffer.write_record_done()
    
    def _write_message_index(self, info, buffer):
        buffer.start_write_record(OperationCode.MESSAGE_INDEX)
        buffer.write_2(info["channel_id"])
        buffer.write_4(len(info["records"]) * 16)
        for record in info["records"]:
            buffer.write_timestamp(record["timestamp"])
            buffer.write_8(record["offset"])
        buffer.write_record_done()
    
    def _write_metadata(self, name, metadata, buffer):
        buffer.start_write_record(OperationCode.METADATA)
        buffer.write_str(name)
        meta_length = 0
        for key, value in metadata.items():
            meta_length += len(key.encode()) + len(value.encode()) + 8
        buffer.write_4(meta_length)
        for key, value in metadata.items():
            buffer.write_str(key)
            buffer.write_str(value)
        buffer.write_record_done()
    
    def _write_data_end(self, buffer):
        buffer.start_write_record(OperationCode.DATA_END)
        buffer.write_4(0)
        buffer.write_record_done()

    def _write_chunk_index(self, info, buffer):
        buffer.start_write_record(OperationCode.CHUNK_INDEX)
        buffer.write_timestamp(info["message_start_time"])
        buffer.write_timestamp(info["message_end_time"])
        buffer.write_8(info["chunk_start_offset"])
        buffer.write_8(info["chunk_length"])
        buffer.write_4(len(info["message_index_offsets"]) * 10)
        for channel_id, index_offset in info["message_index_offsets"].items():
            buffer.write_2(channel_id)
            buffer.write_8(index_offset)
        buffer.write_8(info["message_index_length"])
        buffer.write_str(info["compression"])
        buffer.write_8(info["compressed_size"])
        buffer.write_8(info["uncompressed_size"])
        buffer.write_record_done()
    
    def _write_metadata_index(self, info, buffer):
        buffer.start_write_record(OperationCode.METADATA_INDEX)
        buffer.write_8(info["offset"])
        buffer.write_8(info["length"])
        buffer.write_str(info["name"])
        buffer.write_record_done()
    
    def _write_attachment_index(self, info, buffer):
        buffer.start_write_record(OperationCode.ATTACHMENT_INDEX)
        buffer.write_8(info["offset"])
        buffer.write_8(info["length"])
        buffer.write_timestamp(info["log_time"])
        buffer.write_timestamp(info["create_time"])
        buffer.write_8(info["data_size"])
        buffer.write_str(info["name"])
        buffer.write_str(info["media_type"])
        buffer.write_record_done()
    
    def _write_statistics(self, info, buffer):
        buffer.start_write_record(OperationCode.STATISTICS)
        buffer.write_8(info["message_count"])
        buffer.write_2(info["schema_count"])
        buffer.write_4(info["channel_count"])
        buffer.write_4(info["attachment_count"])
        buffer.write_4(info["metadata_count"])
        buffer.write_4(info["chunk_count"])
        buffer.write_timestamp(info["message_start_time"] or 0)
        buffer.write_timestamp(info["message_end_time"] or 0)
        buffer.write_4(len(info["channel_message_counts"]) * 10)
        for channel_id, msg_count in info["channel_message_counts"].items():
            buffer.write_2(channel_id)
            buffer.write_8(msg_count)
        buffer.write_record_done()

    def _write_summary_offset(self, info, buffer):
        buffer.start_write_record(OperationCode.SUMMARY_OFFSET)
        buffer.write_1(info["group_opcode"])
        buffer.write_8(info["group_start"])
        buffer.write_8(info["group_length"])
        buffer.write_record_done()
    
    def _write_footer(self, info, buffer):
        buffer.start_write_record(OperationCode.FOOTER)
        buffer.write_8(info["summary_start"])
        buffer.write_8(info["summary_offset_start"])
        buffer.write_4(info["summary_crc"])
        buffer.write_record_done()
        buffer.write(b"\x89MCAP0\r\n")


class MCAPWriteHandler(MCAPWriteMixin):
    def __init__(self, stream, chunk_size=1024 * 1024 * 4, compression="", enable_crc=False):
        self.stream = stream
        self.chunk_size = chunk_size
        self.compression = CompressionType(compression)
        self.enable_crc = enable_crc

        self._metadata = {}
        self._summary_offsets = []
        self._channels = {}
        self._schemas = {}
        self._statistics = {
            "message_count": 0,
            "attachment_count": 0,
            "metadata_count": 0,
            "chunk_count": 0,
            "message_start_time": None,
            "message_end_time": None,
            "channel_message_counts": collections.defaultdict(int),
        }

        self._chunk_buffer = BufferWriter()
        self._chunk_data = BufferWriter()
        self._chunk_index = []
        self._chunk_message_index = collections.defaultdict(list)
        self._chunk_start_ts = None
        self._chunk_end_ts = None
        self._ended = False
        
        self._invalid_msg_names = {HAD_MSG_NAME, FRAME_MSG_NAME}
        self._topic_frame_map = {}
        self._frames = set()

    def start_write(self):
        buffer = BufferWriter()
        buffer.write(b"\x89MCAP0\r\n")
        buffer.start_write_record(OperationCode.HEADER)
        buffer.write_str("")
        buffer.write_str(f"CMDK {cmdk.__version__}")
        buffer.write_record_done()
        self.stream.write(buffer.dump())

    def add_metadata(self, name: str, meta: Dict[str, str]):
        if meta:
            self._metadata.setdefault(name, {}).update(meta)

    def get_next_sequence(self, topic):
        if topic not in self._channels:
            return 1
        return self._statistics["channel_message_counts"][self._channels[topic]["id"]] + 1

    def write_raw_message(self, topic: str, payload: Any, payload_type: SchemaEncoding, log_ts_ms: int, publish_ts_ms: int) -> int:
        if " " in topic:
            raise exceptions.InvalidMessageError(f"topic '{topic}' contains space character!")
        
        if payload_type == SchemaEncoding.PROTOBUF:
            if not isinstance(payload, ProtoBufMessage):
                raise exceptions.InvalidMessageError(f"Invalid payload type, must be protobuf!")
            msg_name = payload.DESCRIPTOR.full_name
            channle_encoding = ChannelEncoding.PROTOBUF
            schema_data = ProtobufCodec.export_schema(payload)
            msg_data = ProtobufCodec.encode(payload)
        elif payload_type == SchemaEncoding.JSON:
            if not isinstance(payload, dict):
                raise exceptions.InvalidMessageError(f"Invalid payload type, must be dict for json encoding!")
            msg_data = JsonCodec.encode(payload)
            parts = re.split(r'[\/_\-]+', topic.strip('/'))
            msg_name = "".join(word.capitalize() for word in parts if word)
            channle_encoding = ChannelEncoding.JSON
            builder = SchemaBuilder()
            builder.add_object(payload)
            schema_data = orjson.dumps(builder.to_schema())
        else:
            raise exceptions.InvalidMessageError(f"unsupported payload type '{payload_type}'!")
        
        if log_ts_ms < 1577808000000 or log_ts_ms > 4102416000000:
            raise exceptions.InvalidMessageError(f"Invalid timestamp {log_ts_ms}!")
        
        if topic not in self._channels:
            channel_id = len(self._channels) + 1
            schema_id = len(self._schemas) + 1
            self._schemas[schema_id] = {
                "name": msg_name,
                "encoding": payload_type.value,
                "id": schema_id,
                "data": schema_data,
            }
            self._write_schema(self._schemas[schema_id], self._chunk_data)
            self._channels[topic] = {
                "id": channel_id,
                "topic": topic,
                "encoding": channle_encoding.value,
                "metadata": {},
                "schema_id": schema_id
            }
            self._write_channel(self._channels[topic], self._chunk_data)
        else:
            channel_info = self._channels[topic]
            channel_id = channel_info["id"]
            if msg_name != self._schemas[channel_info["schema_id"]]["name"]:
                raise exceptions.InvalidProtoError(f"Invalid proto message name {msg_name}!")

        self._statistics["channel_message_counts"][channel_id] += 1

        msg_ts = log_ts_ms * 1000000
        self._chunk_message_index[channel_id].append((msg_ts, self._chunk_data.offset))
        self._chunk_data.start_write_record(OperationCode.MESSAGE)
        self._chunk_data.write_2(channel_id)
        self._chunk_data.write_4(self._statistics["channel_message_counts"][channel_id])
        self._chunk_data.write_8(msg_ts)
        self._chunk_data.write_8(publish_ts_ms * 1000000)
        self._chunk_data.write(msg_data)
        self._chunk_data.write_record_done()

        if self._chunk_start_ts is None:
            self._chunk_start_ts = msg_ts
            self._chunk_end_ts = msg_ts
        else:
            self._chunk_start_ts = min(msg_ts, self._chunk_start_ts)
            self._chunk_end_ts = max(msg_ts, self._chunk_end_ts)

        if self._chunk_data.offset > self.chunk_size:
            self._flush_chunk()

        if self._statistics["message_start_time"] is None:
            self._statistics["message_start_time"] = msg_ts
            self._statistics["message_end_time"] = msg_ts
        else:
            self._statistics["message_start_time"] = min(msg_ts, self._statistics["message_start_time"])
            self._statistics["message_end_time"] = max(msg_ts, self._statistics["message_end_time"])

        self._statistics["message_count"] += 1
        return self._statistics["channel_message_counts"][channel_id]

    def write_little_message(
        self,
        topic: str,
        proto: ProtoBufMessage,
        gen_ts: int,
        data: Optional[List[bytes]] = None,
        msg_id: int = None,
        done_ts: int = None,
    ) -> int:
        if topic in self._frames:
            raise exceptions.InvalidMessageError(
                f"Topic {topic} already registered as frame topic, conflict with current little message type!")
        
        if proto.DESCRIPTOR.full_name in self._invalid_msg_names:
            raise exceptions.InvalidMessageError(f"Disallowed proto message type {proto.DESCRIPTOR.full_name}!")
        
        had_pb = mcapsdk_data_pb2.HeaderAndData(gen_ts=gen_ts, done_ts=done_ts or gen_ts, msg_id=msg_id or 0)
        
        if data:
            if not (isinstance(data, list) and all(isinstance(_data, bytes) for _data in data)):
                raise exceptions.InvalidMessageError("data must be a list of bytes!")
            had_pb.data_blocks.extend([mcapsdk_data_pb2.DataBlock(data=_data) for _data in data])
        
        seq1 = self.write_raw_message(topic, proto, SchemaEncoding.PROTOBUF, gen_ts, gen_ts)
        seq2 = self.write_raw_message(f"{topic}/data", had_pb, SchemaEncoding.PROTOBUF, gen_ts, gen_ts)
        if seq1 != seq2:
            raise exceptions.InvalidMessageError(f"{topic} message sequence {seq1} {seq2} does not match!")
        return seq1
    
    def write_frame(self, topic: str, gen_ts: int, messages: List[dict], frame_id: int = None, extra: dict = None):
        if not topic.endswith("/frame"):
            raise exceptions.InvalidMessageError(f"Frame topic '{topic}' must end with '/frame'!")
        
        frame = mcapsdk_frame_pb2.FrameHeader(gen_ts=gen_ts, done_ts=gen_ts, frame_version=1)
        if frame_id is not None:
            frame.frame_id = frame_id
        if extra is not None:
            for field in frame.DESCRIPTOR.fields_by_name:
                if field in extra:
                    setattr(frame, field, extra[field])
        
        self._frames.add(topic)
        
        msg_headers = []

        for msg in messages:
            msg_topic = msg["topic"]
            _frame = self._topic_frame_map.setdefault(msg_topic, topic)
            if _frame != topic:
                raise exceptions.InvalidMessageError(
                    f"Topic {msg_topic} already registed with frame {_frame}, conflict with current frame {topic}!")
            seq = self.write_little_message(
                msg_topic,
                msg["proto"], 
                msg["gen_ts"], 
                msg.get("data"), 
                msg.get("msg_id"), 
                msg.get("done_ts")
            )
            _msg_header = mcapsdk_frame_pb2.MessageHeader(
                gen_ts=msg["gen_ts"],
                done_ts=msg["gen_ts"],
                msg_id=msg.get("msg_id") or 0,
                topic=msg_topic,
                mcap_sequence=seq
            )
            if "user_channel_id" in msg:
                _msg_header.user_channel_id = msg["user_channel_id"]
            msg_headers.append(_msg_header)
        frame.msg_list.extend(msg_headers)
        self.write_raw_message(topic, frame, SchemaEncoding.PROTOBUF, gen_ts, gen_ts)
    
    def _flush_chunk(self):
        if not self._chunk_data.offset:
            return

        chunk_data = self._chunk_data.dump()
        if self.compression == CompressionType.NONE:
            compressed_data = chunk_data
        elif self.compression == CompressionType.LZ4:
            compressed_data = lz4.frame.compress(chunk_data)
        elif self.compression ==  CompressionType.ZSTD:
            compressed_data = zstandard.compress(chunk_data)
        else:
            raise exceptions.UnsupportedError(f"Unknown compression type: {self.compression}")

        chunk_start_offset = self.stream.tell()

        self._chunk_buffer.start_write_record(OperationCode.CHUNK)
        self._chunk_buffer.write_8(self._chunk_start_ts)
        self._chunk_buffer.write_8(self._chunk_end_ts)
        self._chunk_buffer.write_8(len(chunk_data))
        self._chunk_buffer.write_4(zlib.crc32(chunk_data) if self.enable_crc else 0)
        self._chunk_buffer.write_str(self.compression.value)
        self._chunk_buffer.write_8(len(compressed_data))
        self._chunk_buffer.write(compressed_data)
        self._chunk_buffer.write_record_done()

        chunk_length = self._chunk_buffer.offset

        channel_message_index_offsets = {}
        for channel_id, indexes in self._chunk_message_index.items():
            channel_message_index_offsets[channel_id] = chunk_start_offset + self._chunk_buffer.offset

            self._chunk_buffer.start_write_record(OperationCode.MESSAGE_INDEX)
            self._chunk_buffer.write_2(channel_id)
            self._chunk_buffer.write_4(len(indexes) * 16)
            for _msg_ts, offset in indexes:
                self._chunk_buffer.write_8(_msg_ts)
                self._chunk_buffer.write_8(offset)
            self._chunk_buffer.write_record_done()

        message_index_length = self._chunk_buffer.offset - chunk_length

        self.stream.write(self._chunk_buffer.dump())
        self.stream.flush()

        self._chunk_index.append({
            "message_start_time": self._chunk_start_ts,
            "message_end_time": self._chunk_end_ts,
            "chunk_start_offset": chunk_start_offset,
            "chunk_length": chunk_length,
            "message_index_offsets": channel_message_index_offsets,
            "message_index_length": message_index_length,
            "compressed_size": len(compressed_data),
            "uncompressed_size": len(chunk_data)
        })
        self._chunk_message_index.clear()

        self._statistics["chunk_count"] += 1

        self._chunk_start_ts = None
        self._chunk_end_ts = None

    def end_write(self):
        if self._ended:
            return
        self._flush_chunk()
        
        _frame_topics = {}
        for topic, frame in self._topic_frame_map.items():
            _frame_topics.setdefault(frame, []).append(topic)
        self.add_metadata("frame_msg_map", {frame: "###".join(topics) for frame, topics in _frame_topics.items()})

        buffer = BufferWriter()
        _metadata_index = []
        stream_offset = self.stream.tell()

        if self._metadata:
            _item_offset = buffer.offset
            for name, meta in self._metadata.items():
                buffer.start_write_record(OperationCode.METADATA)
                buffer.write_str(name)
                meta_length = 0
                for key, value in meta.items():
                    meta_length += len(key.encode()) + len(value.encode()) + 8
                buffer.write_4(meta_length)
                for key, value in meta.items():
                    buffer.write_str(key)
                    buffer.write_str(value)
                buffer.write_record_done()

                _metadata_index.append({
                    "offset": stream_offset,
                    "length": buffer.offset - _item_offset,
                    "name": name,
                })

        buffer.start_write_record(OperationCode.DATA_END)
        buffer.write_4(0)
        buffer.write_record_done()

        self.stream.write(buffer.dump())
        summary_start = self.stream.tell()
        stream_offset = summary_start
        if self._schemas:
            for info in self._schemas.values():
                self._write_schema(info, buffer)
            stream_new_offset = summary_start + buffer.offset
            self._summary_offsets.append({
                "group_opcode": OperationCode.SCHEMA.value,
                "group_start": stream_offset,
                "group_length": stream_new_offset - stream_offset
            })
            stream_offset = stream_new_offset

        if self._channels:
            for info in self._channels.values():
                self._write_channel(info, buffer)
            stream_new_offset = summary_start + buffer.offset
            self._summary_offsets.append({
                "group_opcode": OperationCode.CHANNEL.value,
                "group_start": stream_offset,
                "group_length": stream_new_offset - stream_offset
            })
            stream_offset = stream_new_offset

        buffer.start_write_record(OperationCode.STATISTICS)
        buffer.write_8(self._statistics["message_count"])
        buffer.write_2(len(self._schemas))
        buffer.write_4(len(self._channels))
        buffer.write_4(0)
        buffer.write_4(len(self._metadata))
        buffer.write_4(self._statistics["chunk_count"])
        buffer.write_8(self._statistics["message_start_time"] if self._statistics["message_start_time"] else 0)
        buffer.write_8(self._statistics["message_end_time"] if self._statistics["message_end_time"] else 0)
        buffer.write_4(len(self._statistics["channel_message_counts"]) * 10)
        for channel_id, msg_count in self._statistics["channel_message_counts"].items():
            buffer.write_2(channel_id)
            buffer.write_8(msg_count)
        buffer.write_record_done()

        stream_new_offset = summary_start + buffer.offset
        self._summary_offsets.append({
            "group_opcode": OperationCode.STATISTICS.value,
            "group_start": stream_offset,
            "group_length": stream_new_offset - stream_offset
        })

        stream_offset = stream_new_offset

        if self._chunk_index:
            for info in self._chunk_index:
                buffer.start_write_record(OperationCode.CHUNK_INDEX)
                buffer.write_8(info["message_start_time"])
                buffer.write_8(info["message_end_time"])
                buffer.write_8(info["chunk_start_offset"])
                buffer.write_8(info["chunk_length"])
                buffer.write_4(len(info["message_index_offsets"]) * 10)
                for channel_id, index_offset in info["message_index_offsets"].items():
                    buffer.write_2(channel_id)
                    buffer.write_8(index_offset)
                buffer.write_8(info["message_index_length"])
                buffer.write_str(self.compression.value)
                buffer.write_8(info["compressed_size"])
                buffer.write_8(info["uncompressed_size"])
                buffer.write_record_done()

            stream_new_offset = summary_start + buffer.offset
            self._summary_offsets.append({
                "group_opcode": OperationCode.CHUNK_INDEX.value,
                "group_start": stream_offset,
                "group_length": stream_new_offset - stream_offset
            })
            stream_offset = stream_new_offset

        if _metadata_index:
            for info in _metadata_index:
                buffer.start_write_record(OperationCode.METADATA_INDEX)
                buffer.write_8(info["offset"])
                buffer.write_8(info["length"])
                buffer.write_str(info["name"])
                buffer.write_record_done()
            stream_new_offset = summary_start + buffer.offset
            self._summary_offsets.append({
                "group_opcode": OperationCode.METADATA_INDEX.value,
                "group_start": stream_offset,
                "group_length": stream_new_offset - stream_offset
            })
            stream_offset = stream_new_offset

        summary_offset_start = stream_offset
        for info in self._summary_offsets:
            buffer.start_write_record(OperationCode.SUMMARY_OFFSET)
            buffer.write_1(info["group_opcode"])
            buffer.write_8(info["group_start"])
            buffer.write_8(info["group_length"])
            buffer.write_record_done()

        summary_crc = 0
        if self.enable_crc:
            summary_data = buffer.dump()
            self.stream.write(summary_data)

            summary_crc = zlib.crc32(summary_data)
            summary_crc = zlib.crc32(
                struct.pack("<BQQQ", OperationCode.FOOTER.value, 20, summary_start, summary_offset_start),
                summary_crc
            )
        buffer.start_write_record(OperationCode.FOOTER)
        buffer.write_8(summary_start)
        buffer.write_8(summary_offset_start)
        buffer.write_4(summary_crc)
        buffer.write_record_done()
        buffer.write(b"\x89MCAP0\r\n")
        self.stream.write(buffer.dump())
        self.stream.flush()
        self._ended = True


class OperationCode(enum.IntEnum):
    HEADER = 0x01
    FOOTER = 0x02
    SCHEMA = 0x03
    CHANNEL = 0x04
    MESSAGE = 0x05
    CHUNK = 0x06
    MESSAGE_INDEX = 0x07
    CHUNK_INDEX = 0x08
    ATTACHMENT = 0x09
    ATTACHMENT_INDEX = 0x0A
    STATISTICS = 0x0B
    METADATA = 0x0C
    METADATA_INDEX = 0x0D
    SUMMARY_OFFSET = 0x0E
    DATA_END = 0x0F

    MAGIC = 0x89
