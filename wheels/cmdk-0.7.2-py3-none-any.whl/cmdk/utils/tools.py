import errno
import fnmatch
import functools
import logging
import os
import socket
import stat
import time
from typing import Callable, Union, Tuple, List

from cmdk.common import settings


logger = logging.getLogger("cmdk")

_NOT_FOUND = object()


class r_property:
    def __init__(self, fget):
        self.fget = fget
        self.name = fget.__name__
        self._c_name = f"_{self.name}_"

    def __get__(self, instance, owner):
        if instance is None:
            raise AttributeError(f"Can only be accessed by {owner} instances!")
        val = instance.__dict__.get(self._c_name, _NOT_FOUND)
        if val is _NOT_FOUND:
            val = self.fget(instance)
            instance.__dict__[self._c_name] = val
        return val

    def __set__(self, instance, value):
        raise AttributeError(f"The property '{self.name}' is not writable!")


class rw_property(r_property):
    def __init__(self, fget):
        super().__init__(fget)
        self._validator = None

    def __set__(self, instance, value):
        if self._validator is not None:
            value = self._validator(instance, value)
        instance.__dict__[self._c_name] = value

    def set_validator(self, fn):
        self._validator = fn
        return self


def retry(
    retries: int = 3, 
    delay: Union[int, float] = 0,
    backoff: int = 1,
    exceptions: Tuple[Exception] = (Exception, ),
    logger: logging.Logger = None
):
    def decorator(func: Callable):
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            _delay = delay
            for attempt in range(1, retries + 1):
                try:
                    return func(*args, **kwargs)
                except exceptions as e:
                    if attempt < retries:
                        if logger:
                            logger.warning(f"Function {func.__name__} attempt {attempt} failed: {e}")
                        if _delay > 0:
                            if logger:
                                logger.debug(f"Function {func.__name__} waiting {_delay}s...")
                            time.sleep(_delay)
                            _delay *= backoff
                    else:
                        if logger:
                            logger.error(f"Function {func.__name__} failed after {retries} retries, raising exception:")
                        raise
        return wrapper
    return decorator


def is_running_on_aidi():
    return "WORKING_PATH" in os.environ and "PBS_JOBNAME" in os.environ


_LOCAL_IP = None
def get_local_ip():
    global _LOCAL_IP
    if _LOCAL_IP is not None:
        return _LOCAL_IP
    ip = None
    if is_running_on_aidi():
        ip = os.environ.get("NODE_NAME")
    if not ip:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        try:
            s.connect(("8.8.8.8", 80))
            ip = s.getsockname()[0]
        except Exception:
            ip = "127.0.0.1"
        finally:
            s.close()
    _LOCAL_IP = ip
    return ip


def is_domain_reachable(domain, port=443, timeout=0.5):
    try:
        with socket.create_connection((domain, port), timeout=timeout):
            return True
    except (socket.timeout, socket.gaierror, ConnectionRefusedError):
        return False


def identify_network():
    ip = get_local_ip()
    if ip.startswith(("10.11.", "10.12.", "10.21.", "10.22."),):
        return (ip, "OFFICE")
    elif ip.startswith("10."):
        return (ip, "CLOUD")
    else:
        if is_domain_reachable("artifacts.autodriving.volcengine.com"):
            return (ip, "CLOUD")
        elif is_domain_reachable("carizon.work"):
            return (ip, "OFFICE")
        else:
            return (ip, "LOCAL")


def _cmdk_getaddrinfo(pached_hosts: dict):
    original_getaddrinfo = socket.getaddrinfo
    def cmdk_getaddrinfo(host, port, family=0, type=0, proto=0, flags=0):
        if host in pached_hosts:
            return [(socket.AF_INET, socket.SOCK_STREAM, 6, "", (pached_hosts[host], port))]
        return original_getaddrinfo(host, port, family, type, proto, flags)
    return cmdk_getaddrinfo


def do_pached_dns(network: str = None):
    if socket.getaddrinfo.__name__ == "cmdk_getaddrinfo":
        return

    if network is None:
        _, network = identify_network()
    if network == "CLOUD":
        socket.getaddrinfo = _cmdk_getaddrinfo(settings.CLOUD_DNS)
    else:
        socket.getaddrinfo = _cmdk_getaddrinfo(settings.OFFICE_DNS)
    logger.info(f"Patched GAIA host resolver for {network} network.")


class BucketPath:
    
    DMP_PREFIX = "dmpv2://"
    MOUNT_PREFIX = "/horizon-bucket/"
    
    def __init__(self, path: Union[str, os.PathLike]):
        path = os.fspath(path)
        if path.startswith(self.DMP_PREFIX):
            self.local_path = f"{self.MOUNT_PREFIX}{path[8:]}"
        else:
            self.local_path = os.path.abspath(path)
        self._stat = None
        self.is_bucket = self._is_bucket_path(self.local_path)

    @r_property
    def bucket_name(self) -> str:
        if self.is_bucket:
            return self.local_path.split("/", 3)[2]
        raise ValueError("Not a bucket path")
    
    @r_property
    def dmp_url(self) -> str:
        if self.is_bucket:
            return f"{self.DMP_PREFIX}{self.local_path[len(self.MOUNT_PREFIX):]}"
        raise ValueError("Not a bucket path")
    
    @r_property
    def parent(self) -> "BucketPath":
        return self.__class__(os.path.dirname(self.local_path))
    
    @r_property
    def name(self) -> str:
        return self.local_path.rsplit("/", 1)[-1]
    
    @r_property
    def stem(self) -> str:
        name = self.name
        i = name.rfind(".", 1)
        if 0 < i < len(name) - 1:
            return name[:i]
        else:
            return name
    
    @r_property
    def suffix(self) -> str:
        name = self.name
        i = name.rfind(".")
        if 0 < i < len(name) - 1:
            return name[i + 1:]
        else:
            return ""
    
    def stat(self) -> os.stat_result:
        if self._stat is None:
            self._stat = os.stat(self.local_path)
        return self._stat
    
    def exists(self) -> bool:
        try:
            self.stat()
        except OSError as e:
            if e.errno == errno.ENOENT:
                return False
        return True

    def is_dir(self) -> bool:
        try:
            return stat.S_ISDIR(self.stat().st_mode)
        except OSError:
            return False

    def listdir(self) -> List["BucketPath"]:
        files = os.listdir(self.local_path)
        files.sort()
        return [
            self.__class__(f"{self.local_path}/{_file}")
            for _file in files
        ]
    
    def glob(self, pattern: str) -> List["BucketPath"]:
        files = os.listdir(self.local_path)
        files.sort()
        return [
            self.__class__(f"{self.local_path}/{_file}")
            for _file in files
            if fnmatch.fnmatch(_file, pattern)
        ]

    @classmethod
    def _is_bucket_path(cls, path: str) -> bool:
        return path.startswith(cls.MOUNT_PREFIX) or path.startswith(cls.DMP_PREFIX)

    @classmethod
    def _is_dmp_url(cls, path: str) -> bool:
        return path.startswith(cls.DMP_PREFIX)
    
    def __str__(self) -> str:
        if self.exists():
            return self.local_path
        return self.dmp_url

    def __fspath__(self) -> str:
        return self.local_path

    def __repr__(self) -> str:
        return f"{self.__class__.__name__}({self.__str__()})"


def copy_from_bucket(from_bucket, target):
    with open(from_bucket, "rb") as fr, open(target, "wb") as fw:
        while True:
            buf = fr.read(4194304)  # 4MB
            if not buf:
                break
            fw.write(buf)
